"""Isolated reversible 60483 candidate, no original files changed."""
from pathlib import Path
import importlib.util,functools,numpy as np,math
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('baseline60483',HERE/'source/baseline_model.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files={};n=None
for line in (HERE/'source/baseline-machine-899.mpd').read_text().splitlines():
 if line.startswith('0 FILE '):n=line[7:].replace('\\','/').lower();files[n]=[]
 elif n:files[n].append(line)
for p in (HERE/'parts').glob('*.dat'):
 name=('s/'if p.name=='60483s01.dat'else'')+p.name;files[name]=p.read_text().splitlines()
def resolve(n):
 n=n.replace('\\','/').lower()
 for k in [n,'p/'+n,'parts/'+n,'s/'+n]:
  if k in files:return k
 raise KeyError(n)
@functools.lru_cache(None)
def mesh(n):
 tris=[]
 for line in files[resolve(n)]:
  s=line.split()
  if not s:continue
  if s[0]=='1':
   v=np.array(s[2:14],float);tris.extend(mesh(' '.join(s[14:]))@v[3:].reshape(3,3).T+v[:3])
  elif s[0]=='3':tris.append(np.array(s[2:11],float).reshape(3,3))
  elif s[0]=='4':
   q=np.array(s[2:14],float).reshape(4,3);tris.extend([q[[0,1,2]],q[[0,2,3]]])
 return np.asarray(tris).reshape(-1,3,3)
def world(p):return (mesh(p.name)@p.rot.T+p.pos)*.4
def replace_module(pp):
 out=[];new=[];removed=[]
 for p in pp:
  if p.note in ['开限位挡轴','开限位挡轴轴套'] or (p.name=='32056.dat'and p.note=='限位支架'):
   removed.append(p)
   continue
  out.append(p)
 # Obtain pair centroids and exact transformed old local axes. No world pose assumptions.
 old=[p for p in removed if p.name=='32056.dat'];used=set()
 for i,p in enumerate(old):
  if i in used:continue
  j=next(j for j,q in enumerate(old)if j!=i and j not in used and np.allclose(p.rot,q.rot)and abs(np.linalg.norm(p.pos-q.pos)-10)<1e-6)
  used.update([i,j]);q=old[j]
  # 60483 cross hole at local0, round at local+Z20. Old root at old+Z40.
  R=p.rot@np.diag([-1.,1.,-1.]);pos=(p.pos+q.pos)/2+p.rot@np.array([0,0,40.])
  a=m.Part('60483.dat',p.color,pos,R,p.step,'60483根轴支架（无开挡轴）');a.arm,a.head,a.sub=p.arm,p.head,p.sub
  out.append(a);new.append(a)
 assert len(old)==8 and len(new)==4 and len(removed)==14 and len(out)==len(pp)-10
 return out
BASE_MODULE=m.module

def module(open_s=0.,angle=0.,steps=False,on_base=True):return replace_module(BASE_MODULE(open_s,angle,steps,on_base))
def state_parts(state,candidate=True):
 pp=[]
 for arm in m.ARMS:
  s,a=state.get(arm,(0.,0.));mm=module(s,a)if candidate else BASE_MODULE(s,a,False,True)
  for p in mm:q=p.moved(m.ARM_ROT[arm]);q.arm=arm;pp.append(q)
 return pp

def natural_stroke():
 h=m.CRANK_C[1]-m.BLOCK_Y;th=-math.atan2(h,math.sqrt((m.LINK2_L+m.CRANK_R)**2-h*h))
 cp=m.CRANK_C+m.CRANK_R*np.array([math.cos(th),math.sin(th)])
 return float(cp[0]+math.sqrt(m.LINK2_L**2-(cp[1]-m.BLOCK_Y)**2)-m.BLOCK_X_CLOSED)
