RETAINED MODULE OVERTRAVEL SCREEN — LIMITED, NOT AN OPERATIONAL RELEASE

Result
No newly observed strict triangle-crossing pair was found in 121 equally
spaced opening-angle samples from 25.0000000 to 30.872250307 degrees.
All 23 positive crossing pairs were already positive at 25 degrees and remain
positive at every sampled state. Many involve modeled shaft/pin/tyre mates;
the servo body–crank pair is also inherited. None is silently waived as safe.
The normal commanded endpoint remains 25 degrees. This screen does not
approve commanding the natural endpoint or removing physical protection.

Scope
One complete local candidate module has 167 parts. The four new 60483 brackets
are excluded from this retained-only audit and are checked separately by the
parent audit. Of 163 retained parts, 39 change pose with opening: 31 head parts
and 8 nonhead servo-linkage parts. Each pose tests all 5,577 retained pairs with
at least one opening-moving member: 1,643 head/head, 3,218 head/nonhead and 716
nonhead/nonhead. The triangle sweep uses head roll 0 degrees. Common roll of
both head parts cancels exactly, so head/head results apply to all head roll.
Stroke increases 32.307676505→38.548709394 LDU (12.923070602→15.419483758 mm).
OPEN_S is changed only in each script's Python process; no source model edit.

Continuous retained-head bounds, valid through full overtravel and all roll
  1,508 pairs: positive conservative separating-plane/box clearance
    1,506 from 256 analytic subinterval envelopes; 2 from 64 plane envelopes.
      111 pairs: rigidly comoving, geometry unchanged relative to25 degrees
       14 pairs: boundary-only separation bound; no positive clearance shown
       10 pairs: overlapping envelopes remain unresolved
Total: 1,643 affected retained-head pairs.
The two refined nonmate pairs, root bush123/link158 and bush130/link160,
have certified conservative plane gaps>=8.248329 mm over the complete sweep.

The 10 unresolved retained-head pairs (zero-based IDs in candidate.module):
  114 18938 turntable upper /162 3708 pushrod: no sampled strict crossing
  115 39793 pushrod guide  /162 3708 pushrod: no sampled strict crossing
  120 32524 upper jaw /121 3707 root axle: inherited strict crossing
  120 32524 upper jaw /159 3673 linkage pin: inherited strict crossing
  128 32524 lower jaw /129 3707 root axle: inherited strict crossing
  128 32524 lower jaw /161 3673 linkage pin: inherited strict crossing
  155 3705 crosshead axle /158 32316 upper link: inherited strict crossing
  155 3705 crosshead axle /160 32316 lower link: inherited strict crossing
  158 32316 upper link /159 3673 linkage pin: inherited strict crossing
  160 32316 lower link /161 3673 linkage pin: inherited strict crossing
These are nominal joint/bore relationships requiring a separate fit audit,
not permission to ignore interference. The 14 boundary-only pairs, including
some link/sideplate/pin relations, are enumerated in continuous-separation.json.
The envelope touching a boundary does not establish actual surface contact.

Continuous head/nonhead bounds across full 360 degree head roll
  3,111 affected pairs: positive axial separation
     99 more: positive cylinder/radial separation
      8 remain unresolved; no arbitrary-roll surface/containment check:
        bush87 /frame62; bush87 /crossblock86
        bush88 /frame62; bush88 /crossblock86
        rod162 /wall frame0; rod162 /turntable lower33
        rod162 /guide frame62; rod162 /crossblock86
All 8 are negative for the strict triangle test at every sampled roll 0 pose.
No positive-clearance or bore-fit claim is made for them.
The 716 affected nonhead/nonhead pairs have only the sampled screen, not a
continuous certificate. Inherited fixed/fixed geometry is outside this
incremental opening-extension audit. Other modules, supports, base plates
outside module(), cube, cables, tools and assembly paths are not included.

Evidence / reproduction
Run from any directory with Python 3 + NumPy and g++ available:
  PYTHONDONTWRITEBYTECODE=1 python screen.py
  PYTHONDONTWRITEBYTECODE=1 python continuous_bounds.py
  PYTHONDONTWRITEBYTECODE=1 python refine_bounds.py
  PYTHONDONTWRITEBYTECODE=1 python verify_results.py
Scripts reside together in this directory and load ../../candidate.py and
its packaged local source/parts. screen.py compiles the included collision.cpp
with g++ if collision.so is absent. No external audit file is needed at runtime.
JSON files contain part identities, all pair classifications, actual triangle
witnesses and source hashes. verification.log records result-consistency and
unchanged-source checks. IDs are zero-based stable module-list indices.

Limits of evidence
Strict detector recognizes only noncoplanar edge-interior / triangle-interior
crossings. A negative test does not exclude coplanar overlap, containment,
edge-only contact or tiny/numerically degenerate crossings. Sampling is not
continuous proof. Positive continuous bounds use analytic maximum vertex
speeds in 256 closed angular intervals and exact unchanged Z extents; further
plane/cylinder bounds are also conservative analytic enclosures, evaluated
with floating-point tolerance 1e-7 mm, not formal outward-rounded arithmetic.
Rigid-comoving pairs retain whatever fit existed at 25 degrees; their original
fit is not certified. Nominal boundary separation is not real running gap.
Meshes do not certify tolerance, deformation, preload, stiffness, backlash,
wear, axle retention, control limits or force at the crank's natural toggle.
