from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent
s=json.loads((H/'retained-overtravel-screen.json').read_text());b=json.loads((H/'continuous-separation.json').read_text());r=json.loads((H/'refined-separation.json').read_text())
assert s['sample_count']==len(s['sample_stats'])==121
assert s['tested_pair_count']==5577
assert len(s['crossing_pairs'])==23 and all(q['baseline_25_hit']for q in s['crossing_pairs'])
assert s['newly_observed_crossing_pairs']==[]
assert all(q['sample_indices']==list(range(121))for q in s['crossing_pairs'])
assert sum(len(b[k])for k in ['rigid_comoving_pairs','positive_separation_pairs','nominal_boundary_contact_pairs','unresolved_head_pairs'])==b['head_pair_count']==1643
assert all(q['continuous_certified_plane_gap_mm']>8.24 for q in r['continuous_head_plane_certificates'])
assert len(b['fullroll_head_nonhead_axially_separated_pairs'])+len(r['fullroll_radially_separated_pairs'])+len(r['fullroll_unresolved_pairs'])==3218
assert len(r['fullroll_unresolved_pairs'])==8
for p,h in s['source_hashes'].items():assert hashlib.sha256((H.parents[1]/p).read_bytes()).hexdigest()==h
print('PASS:121 complete samples;5,577 pairs each;23 persistent inherited hits;0 newly observed pairs;1,643 head pair partition;3,218 fullroll head/nonhead partition;source hashes unchanged.')
