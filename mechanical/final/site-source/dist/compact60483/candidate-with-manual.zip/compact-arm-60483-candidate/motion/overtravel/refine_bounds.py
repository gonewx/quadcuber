"""Refine the two head-bush/link nonmate boxes using continuous plane bounds;
refine full-roll head/nonhead X-overlap cases with radial cylinder separation.
"""
from pathlib import Path
import sys,math,json,numpy as np
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parents[1]));import candidate as c
r=json.loads((H/'continuous-separation.json').read_text());src=json.loads((H/'retained-overtravel-screen.json').read_text());s0,s1=src['stroke_interval_ldu'];b0,b1=np.radians(src['beta_interval_deg']);c.m.OPEN_S=s1;p0=c.module(s0);p1=c.module(s1);w0={i:c.world(p)for i,p in enumerate(p0)};w1={i:c.world(p)for i,p in enumerate(p1)}
# Fixed separating directions chosen before any output; projection interval at
# every midpoint is expanded by analytic maximum vertex displacement over
# that entire subinterval. Each resulting positive plane gap is continuous.
angles=np.arange(64)*math.pi/64;axes=np.stack([np.cos(angles),np.sin(angles),np.zeros(64)],axis=-1)
plane=[]
for i,j in [(123,158),(130,160)]:
 minimum=1e9;used=set();v=r['vertex_speed_bounds_mm_per_beta_rad'][str(j)];a=w0[i].reshape(-1,3)@axes.T;alo=a.min(0);ahi=a.max(0)
 for lo,hi in zip(np.linspace(b0,b1,65)[:-1],np.linspace(b0,b1,65)[1:]):
  mid=(lo+hi)/2;s=c.m.cross_x_for_beta(mid)-c.m.CROSS_CLOSED_X;p=c.module(s)[j];q=c.world(p).reshape(-1,3)@axes.T;e=v*(hi-lo)/2;blo=q.min(0)-e;bhi=q.max(0)+e;g=np.maximum(alo-bhi,blo-ahi);k=int(g.argmax());minimum=min(minimum,float(g[k]));used.add(k)
 plane.append({'pair':[i,j],'continuous_certified_plane_gap_mm':minimum,'subintervals':64,'axis_indices':sorted(used),'axes':axes[sorted(used)].tolist()})
# Every X-overlap head here is a translating axial rod/bush. Its entire 360deg
# swept solid is contained in a cylinder with the exact maximum vertex radius.
# Nonhead fixed/translated parts have unchanged YZ bounds. All rotating servo
# components have unchanged Z bounds, providing a weaker but valid radius bound.
radial=[];left=[]
for q in r['fullroll_head_nonhead_unresolved_pairs']:
 i,j=q['head'],q['nonhead'];assert i in [87,88,162];rad=float(np.linalg.norm(w0[i][...,1:],axis=-1).max())
 if j not in [92,93,94,95]:
  lo=w0[j].min((0,1))[1:];hi=w0[j].max((0,1))[1:];d=np.maximum(np.maximum(lo,-hi),0);rmin=float(np.linalg.norm(d));method='distance from axis to invariant YZ rectangle'
 else:
  lo=w0[j][...,2].min();hi=w0[j][...,2].max();rmin=float(max(lo,-hi,0));method='invariant Z slab only'
 z={'head':i,'nonhead':j,'head_swept_radius_mm':rad,'nonhead_min_radius_lower_bound_mm':rmin,'continuous_radial_gap_mm':rmin-rad,'method':method}
 (radial if rmin-rad>1e-7 else left).append(z)
r2={'continuous_head_plane_certificates':plane,'fullroll_radially_separated_pairs':radial,'fullroll_unresolved_pairs':left,'counts':{'additional_positive_head_pairs':sum(q['continuous_certified_plane_gap_mm']>1e-7 for q in plane),'additional_positive_fullroll_head_nonhead_pairs':len(radial),'remaining_fullroll_head_nonhead_unresolved':len(left)},'limits':['Strict surface test at roll0 is the only sampled mesh test for remaining fullroll pairs; no arbitrary-roll full mesh sweep or containment/coplanar certification.','Cylinders enclose represented meshes; model tolerances and real joint fit are not certified.']}
(H/'refined-separation.json').write_text(json.dumps(r2,ensure_ascii=False,indent=2));print(json.dumps(r2,ensure_ascii=False,indent=2)[:4000]);print('REMAIN',left)
