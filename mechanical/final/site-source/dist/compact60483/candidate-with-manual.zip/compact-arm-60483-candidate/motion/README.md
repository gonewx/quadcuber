# Incremental motion audit: compact 60483 brackets

## Result

**PASS for the new brackets’ continuous nominal free space.** No unresolved nonmating pair remains in the incremental audit. This result is a geometric clearance result, not a physical-load or safety certification. Keep the normal opening command at **25°**.

Four 60483 brackets per head replace eight 32056 thin L brackets, and the two stop axles/four stop-axle half bushes are removed. Retained geometry at a given configuration is unchanged. Therefore the ordinary-range comparison checks every new bracket against everything else; it does not repeat the earlier retained-to-retained qualification.

| Continuous scope | Pair checks | Conservative minimum clearance |
|---|---:|---:|
| New brackets against nonmating components of their own head, close through natural maximum | 272, representative head | 0.800000 mm |
| All 16 brackets against all nonhead parts in the four modules, including full servo motion | 6,016 | 26.400000 mm |
| All 16 brackets against every other head, independent full 360° roll and ordinary close–25° opening | 3,504 | 4.426871 mm |
| Same other-head comparison through nominal natural 30.872250° opening | 3,504 | 0.874421 mm |
| All 16 brackets against support132 + retained59 base components; support continuously 0–40 mm down and brackets independently full 360° roll | 3,056 | 0.735850 mm |
| New brackets against the 56 mm cube’s complete vertical insertion/withdrawal corridor | All bracket roll states | 32.400000 mm |

A centered 56 mm cube undergoing arbitrary rigid rotation is also separated from every new bracket: its circumsphere radius is 28√3 = 48.497423 mm, while each bracket has at least one horizontal axial coordinate with magnitude 60.4 mm. The resulting conservative gap is 11.902577 mm.

These are sufficient lower bounds, not computed closest surface distances. The smallest bound is 0.735850 mm against the moving rear 32140 support brackets, leaving 0.435850 mm beyond a 0.3 mm free-space allowance. Installed keys are included at their upper pose; their removal/insertion trajectory is not checked.

## Why this is continuous, rather than merely a sampled screen

The 60483 parts are fixed in their head frame; opening the jaws does not move them relative to that frame. Their native axial extent is −67.6 to −60.4 mm and their outer roll radius is 51.816600 mm. A full-rotation cylinder encloses their entire continuous roll sweep exactly as an outer bound.

Retained head native-vertex bounds are evaluated at 641 opening angles separately for the ordinary and natural ranges. Between samples, every point is covered by an analytic speed-based dilation. The derivative bound is derived from the current linkage and native mesh pivot radii, not borrowed from a previous model. The largest bound is 81.198525 mm per jaw-angle radian. The largest nearest-sample allowances are 0.023426 mm for the normal range and 0.029928 mm for the natural range; the actual per-part allowance is used. Consequently all positions between samples are covered.

Servo-side nonhead bodies use exact translation envelopes, full crank-circle envelopes and arbitrary-orientation circumspheres. This avoids a false finite derivative assumption at the natural crank extension toggle. The moving support’s entire 40 mm translation is covered by the exact swept AABB union. Separation from the bracket full-roll cylinder is checked axially or radially. Envelope overlap would be unresolved, never reported as a collision or a pass; none remains.

The support comparison proves a superset of the requested route:
1. All heads rolled 50°, jaws normally open, load the centered cube vertically.
2. Roll FB 50°→0°, then close FB while LR remain 50°/open.
3. Remove both upper keys and lower the support 40 mm.
4. Roll LR 50°→90°, then close LR while FB hold at 0°.
5. Reverse the same configurations for unloading, with support and keys reestablished before opening FB.

Arbitrary solver terminal-state recovery and key extraction/insertion paths are outside that claim.

## Intentional local joints

Each bracket has four expected local mating pairs: its existing root axle, existing fixation pin, inner-beam seating face and outer half-bush seating face. Their relative positions do not change during opening or roll. They are excluded from free-space requirements and listed individually in the JSON.

The supplementary strict triangle-crossing check sees only the fixation pin for these mates. A triangle crossing in a nominal friction-pin assembly is not, by itself, an unintended rigid collision. The separate native engagement audit classifies the friction features and polygonal approximation. Coplanar face contact and bore occupancy are not certified by the strict-crossing routine alone.

## Natural endpoint: deliberately separate status

The nominal servo/linkage endpoint is 38.548709 LDU = 15.419484 mm of stroke, corresponding to a jaw angle of 30.872250°. This is **not a new commanded operating limit**. The old roughly-30° stop has been removed, which changes abnormal-overtravel protection.

The continuous clearance result above covers the new brackets even at that endpoint. It does not automatically qualify every retained component pair for the newly accessible 25°–30.872250° range. The separate `overtravel/` retained-pair screen records that distinction and its unresolved limitations. An absence of new sampled crossings is not a continuous all-pairs certificate.

## Reproduction

From any working directory:

    python /path/to/compact-arm-60483-candidate/motion/audit_motion.py

Requirements: Python 3, NumPy. The package’s `candidate.py`, frozen `source/` and `parts/` files supply all geometry. `collision.cpp` is included; if the shared library is absent, the script builds it with g++ (`-O3 -std=c++17 -shared -fPIC`). The delivery archive may omit the architecture-specific `.so`; g++ is then required on the first run. On a different platform, adapt the native library build as appropriate. No files outside this candidate package are read by the audit.

Outputs:
- `motion-audit.json`: source hashes, classifications, analytical motion bounds, margins, limiting pairs, intended mates and scope
- `continuous-envelopes.npz`: normal/natural continuous envelopes and per-part allowances
- `run.log`: the recorded execution
- `overtravel/`: separate retained-pair overtravel screen

Source files and original models are never modified. The temporary in-process normal-stroke guard extension is analysis-only. Bounds use nominal native geometry and double precision with a 1e-9 mm allowance; this is not formal interval arithmetic or a manufacturing-tolerance analysis.

## Remaining limitations

No claim is made for grip force, stiffness changes after removing the cross-stop axles, fatigue, assembly insertion access, production tolerances, actual servo calibration, sensor/control implementation, or real-hardware operation. Previously inherited issues and the separate retained-overtravel limitations remain. Physical low-force, unloaded checking should precede powered operation, with the normal 25° software endpoint retained.
