#include <vector>
#include <algorithm>
#include <numeric>
#include <cmath>
using namespace std;
struct V { double x[3]; V operator-(const V&o)const{return{{x[0]-o.x[0],x[1]-o.x[1],x[2]-o.x[2]}};} };
double dot(V a,V b){return a.x[0]*b.x[0]+a.x[1]*b.x[1]+a.x[2]*b.x[2];}
V cross(V a,V b){return{{a.x[1]*b.x[2]-a.x[2]*b.x[1],a.x[2]*b.x[0]-a.x[0]*b.x[2],a.x[0]*b.x[1]-a.x[1]*b.x[0]}};}
struct T{V p[3];};
struct N{V lo,hi;int start,end,l=-1,r=-1;};
struct Mesh{vector<T> t;vector<int> ids;vector<N> ns;
 int build(int s,int e){N n;n.start=s;n.end=e;for(int k=0;k<3;k++){n.lo.x[k]=1e30;n.hi.x[k]=-1e30;}for(int i=s;i<e;i++)for(int v=0;v<3;v++)for(int k=0;k<3;k++){n.lo.x[k]=min(n.lo.x[k],t[ids[i]].p[v].x[k]);n.hi.x[k]=max(n.hi.x[k],t[ids[i]].p[v].x[k]);}int q=ns.size();ns.push_back(n);if(e-s>8){int k=0;for(int j=1;j<3;j++)if(n.hi.x[j]-n.lo.x[j]>n.hi.x[k]-n.lo.x[k])k=j;int mid=(s+e)/2;nth_element(ids.begin()+s,ids.begin()+mid,ids.begin()+e,[&](int a,int b){double x=0,y=0;for(int v=0;v<3;v++){x+=t[a].p[v].x[k];y+=t[b].p[v].x[k];}return x<y;});ns[q].l=build(s,mid);ns[q].r=build(mid,e);}return q;}
};
bool overlap(const N&a,const N&b){for(int k=0;k<3;k++)if(a.lo.x[k]>b.hi.x[k]+1e-8||b.lo.x[k]>a.hi.x[k]+1e-8)return false;return true;}
bool edge(V p,V q,const T&t){V d=q-p,e1=t.p[1]-t.p[0],e2=t.p[2]-t.p[0],h=cross(d,e2);double det=dot(e1,h),ep=1e-7;if(abs(det)<ep)return false;V s=p-t.p[0],qq=cross(s,e1);double u=dot(s,h)/det,v=dot(d,qq)/det,tt=dot(e2,qq)/det;return u>ep&&u<1-ep&&v>ep&&u+v<1-ep&&tt>ep&&tt<1-ep;}
bool strict(const T&a,const T&b){for(int i=0;i<3;i++)if(edge(a.p[i],a.p[(i+1)%3],b)||edge(b.p[i],b.p[(i+1)%3],a))return true;return false;}
bool hit(Mesh*a,int ai,Mesh*b,int bi,int*out){const N&an=a->ns[ai],&bn=b->ns[bi];if(!overlap(an,bn))return false;if(an.l<0&&bn.l<0){for(int i=an.start;i<an.end;i++)for(int j=bn.start;j<bn.end;j++)if(strict(a->t[a->ids[i]],b->t[b->ids[j]])){out[0]=a->ids[i];out[1]=b->ids[j];return true;}return false;}if(an.l<0)return hit(a,ai,b,bn.l,out)||hit(a,ai,b,bn.r,out);if(bn.l<0)return hit(a,an.l,b,bi,out)||hit(a,an.r,b,bi,out);if(an.end-an.start>bn.end-bn.start)return hit(a,an.l,b,bi,out)||hit(a,an.r,b,bi,out);return hit(a,ai,b,bn.l,out)||hit(a,ai,b,bn.r,out);}
extern "C"{void* make_mesh(double*ptr,int n){Mesh*m=new Mesh;m->t.resize(n);for(int i=0;i<n;i++)for(int j=0;j<3;j++)for(int k=0;k<3;k++)m->t[i].p[j].x[k]=ptr[i*9+j*3+k];m->ids.resize(n);iota(m->ids.begin(),m->ids.end(),0);m->build(0,n);return m;}void free_mesh(void*p){delete(Mesh*)p;}int mesh_hit(void*a,void*b,int*out){return hit((Mesh*)a,0,(Mesh*)b,0,out);}}
