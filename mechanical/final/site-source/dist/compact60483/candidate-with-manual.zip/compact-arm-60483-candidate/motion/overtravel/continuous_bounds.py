"""Conservative continuous envelopes for opening overtravel.
Head vertices: exact z extent + analytic maximum planar displacement from a
mid-state. No inference of positive separation from sampling or triangle tests.
Pairs rigidly comoving are distinguished from positive-clearance certificates.
"""
from pathlib import Path
import sys,math,json,itertools,numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parents[1]));import candidate as c
src=json.loads((HERE/'retained-overtravel-screen.json').read_text());MOV=src['moving_indices'];B0,B1=np.radians(src['beta_interval_deg']);S0,S1=src['stroke_interval_ldu'];c.m.OPEN_S=S1
pp0=c.module(S0);pp1=c.module(S1);W0={i:c.world(p)for i,p in enumerate(pp0)};W1={i:c.world(p)for i,p in enumerate(pp1)}
HEAD=[i for i,p in enumerate(pp0[:163])if p.head]
PAIRS=[(i,j)for i,j in itertools.combinations(HEAD,2)if i in MOV or j in MOV]
FIX=[i for i in HEAD if i not in MOV];TRANS=[87,88,154,155,156,157,162];JPOS=[120,*range(136,145)];JNEG=[128,*range(145,154)];LINK=[158,160];PIN=[159,161]
GROUP={i:'head_fixed'for i in FIX}|{i:'translation'for i in TRANS}|{i:'positive_jaw'for i in JPOS}|{i:'negative_jaw'for i in JNEG}|{158:'positive_link',160:'negative_link',159:'positive_pin',161:'negative_pin'}
assert set(GROUP)==set(HEAD)
# ds/dbeta = 40sin(beta) +40(80-40sin(beta))cos(beta)/sqrt(80^2-(80-40sin(beta))^2)
ymax=80-40*math.sin(B0);rootmin=math.sqrt(80**2-ymax**2)
SMAX=40*math.sin(B1)+40*ymax*math.cos(B0)/rootmin
V={i:0. for i in HEAD}
for group,sy in [(JPOS,1),(JNEG,-1)]:
 pivot=np.array([c.m.PIVOT_X+c.m.MODULE_DX,sy*c.m.JAW_Y,0])*.4
 for i in group:V[i]=float(np.linalg.norm((W0[i]-pivot)[...,:2],axis=-1).max())
for i in PIN:V[i]=.4*c.m.JAW_A
for i in LINK:
 # Its local beam length axis z maps to moving unit direction d; local x to
 # the planar perpendicular, local y to constant module z.
 local=c.mesh(pp0[i].name);rad=float(np.linalg.norm(local[...,::2],axis=-1).max())
 V[i]=.4*((SMAX+40)/2+rad*(SMAX+40)/80)
for i in TRANS:V[i]=.4*SMAX

def boxes(lo,hi):
 mid=(lo+hi)/2;ss=[min(S1,c.m.cross_x_for_beta(x)-c.m.CROSS_CLOSED_X)for x in [lo,mid,hi]]
 pp=c.module(ss[1]);out={}
 for i in HEAD:
  if i in FIX:w=W0[i];box=np.array([w.min((0,1)),w.max((0,1))])
  elif i in TRANS:
   box=np.array([W0[i].min((0,1)),W0[i].max((0,1))]);box[0,0]+=.4*(ss[0]-S0);box[1,0]+=.4*(ss[2]-S0)
  else:
   w=c.world(pp[i]);box=np.array([w.min((0,1)),w.max((0,1))]);rad=V[i]*(hi-lo)/2;box[0,:2]-=rad;box[1,:2]+=rad
  out[i]=box
 return out

def gap(a,b):
 g=np.maximum(a[0]-b[1],b[0]-a[1]);return float(g.max()),int(g.argmax())
# 256 intervals reduce conservative envelope width. Every interval is covered
# analytically, with one real-arithmetic sphere bound, rather than sampling.
K=256;grid=np.linspace(B0,B1,K+1);mins={q:float('inf')for q in PAIRS};axis_hist={q:set()for q in PAIRS};globalbox={i:np.array([[np.inf]*3,[-np.inf]*3])for i in HEAD}
for lo,hi in zip(grid[:-1],grid[1:]):
 bb=boxes(lo,hi)
 for i in HEAD:globalbox[i][0]=np.minimum(globalbox[i][0],bb[i][0]);globalbox[i][1]=np.maximum(globalbox[i][1],bb[i][1])
 for q in PAIRS:
  g,a=gap(bb[q[0]],bb[q[1]]);mins[q]=min(mins[q],g);axis_hist[q].add(a)
rigid=[];positive=[];boundary=[];unresolved=[]
hits={tuple(q['pair']):q for q in src['crossing_pairs']}
for q in PAIRS:
 rec={'pair':q,'minimum_certified_axis_gap_mm':mins[q],'separating_axes_seen':sorted(axis_hist[q]),'strict_crossing_at25':q in hits and hits[q]['baseline_25_hit'],'strict_crossing_at_any_sample':q in hits}
 if GROUP[q[0]]==GROUP[q[1]]:rec['group']=GROUP[q[0]];rigid.append(rec)
 elif mins[q]>1e-7:positive.append(rec)
 elif mins[q]>=-1e-7:boundary.append(rec)
 else:unresolved.append(rec)
# Full-roll head->nonhead axial test: roll about X never changes X extent.
# For opening-static nonhead bodies the axial extent is exact. For translation
# bodies also exact from endpoints. Crank/link bounding primitives cover all
# theta between endpoints. Servo95 endpoints length120; planar orientation can
# be enclosed more tightly but this conservative sphere is sufficient here.
NON=[i for i,p in enumerate(pp0[:163])if not p.head]
nb={}
for i in NON:
 a,b=W0[i],W1[i]
 if i not in [92,93,94,95]:nb[i]=[float(min(a[...,0].min(),b[...,0].min())),float(max(a[...,0].max(),b[...,0].max()))]
 elif i in [93,94]:
  # crank endpoint sweeps20LDU circle; native part orientation constant.
  localx=(c.mesh(pp0[i].name)@pp0[i].rot.T)[...,0]*.4;cx=(c.m.CRANK_C[0]+c.m.MODULE_DX)*.4
  nb[i]=[float(cx-8+localx.min()),float(cx+8+localx.max())]
 elif i==92:
  rad=float(np.linalg.norm(c.mesh(pp0[i].name)[...,[0,2]],axis=-1).max())*.4;cx=pp0[i].pos[0]*.4;nb[i]=[cx-rad,cx+rad]
 else:
  # center mean of crank endpoint and translating block; add full local
  # rotation radius in XY to its complete possible center interval.
  rad=float(np.linalg.norm(c.mesh(pp0[i].name)[...,[0,2]],axis=-1).max())*.4
  cp=(c.m.CRANK_C[0]+c.m.MODULE_DX)*.4;bxlo=(c.m.BLOCK_X_CLOSED+S0+c.m.MODULE_DX)*.4;bxhi=bxlo+.4*(S1-S0)
  nb[i]=[(cp-8+bxlo)/2-rad,(cp+8+bxhi)/2+rad]
roll_sep=[];roll_unresolved=[]
for i in HEAD:
 for j in NON:
  if i not in MOV and j not in MOV:continue
  a=globalbox[i][:,0];b=nb[j];g=max(a[0]-b[1],b[0]-a[1]);rec={'head':i,'nonhead':j,'minimum_x_gap_mm':float(g)}
  (roll_sep if g>1e-7 else roll_unresolved).append(rec)
r={'method':'Analytic planar vertex displacement Lipschitz envelopes over256 closed beta intervals; exact unchanged z extents. Translation envelope exact from monotone s(beta). Result is conservative in real arithmetic with floating-point numerical tolerance1e-7mm, not formal outward-rounded interval arithmetic.','beta_interval_deg':src['beta_interval_deg'],'head_pair_count':len(PAIRS),'subinterval_count':K,'analytic_ds_dbeta_upper_ldu_per_rad':SMAX,'vertex_speed_bounds_mm_per_beta_rad':V,'rigid_comoving_pairs':rigid,'positive_separation_pairs':positive,'nominal_boundary_contact_pairs':boundary,'unresolved_head_pairs':unresolved,'fullroll_head_nonhead_axially_separated_pairs':roll_sep,'fullroll_head_nonhead_unresolved_pairs':roll_unresolved,'head_swept_bounds_mm':{i:b.tolist()for i,b in globalbox.items()},'nonhead_swept_x_bounds_mm':nb,'counts':{'head_pairs':len(PAIRS),'rigid_comoving':len(rigid),'positive_separation':len(positive),'nominal_boundary':len(boundary),'unresolved_head':len(unresolved),'fullroll_head_nonhead_axially_separated':len(roll_sep),'fullroll_head_nonhead_unresolved':len(roll_unresolved)},'limits':['Rigid comoving certifies no geometry change relative25deg; does not certify existing joint correctness.','Boundary-only separation is zero nominal clearance, not physical clearance.','Unresolved pair envelopes do not imply actual collision.','Axial fullroll screen only addresses pairs with at least one opening-moving member.','No external support, adjacent module or cube geometry included.']}
(HERE/'continuous-separation.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r['counts'],indent=2));print('head unresolved',[(q['pair'],q['strict_crossing_at_any_sample'])for q in unresolved]);print('roll unresolved',[(q['head'],q['nonhead'])for q in roll_unresolved])
