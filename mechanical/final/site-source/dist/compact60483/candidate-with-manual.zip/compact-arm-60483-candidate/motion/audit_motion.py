"""Reproducible incremental motion proof for 60483 candidate.
Run: python motion/audit_motion.py from any directory.
All output is confined to motion/. Source model never modified.
C++ strict-crossing screen is supplementary: it excludes coplanar and containment.
"""
from pathlib import Path
import sys,json,numpy as np,math,hashlib,ctypes,subprocess,collections,time
HERE=Path(__file__).resolve().parent;CAND=HERE.parent
sys.path.insert(0,str(CAND));import candidate as c
m=c.m;start=time.time();ordinary_s=m.OPEN_S;natural_s=c.natural_stroke();natural_beta=m.jaw_beta(natural_s)
if not(HERE/'collision.so').exists():subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',str(HERE/'collision.cpp'),'-o',str(HERE/'collision.so')],check=True)
lib=ctypes.CDLL(str(HERE/'collision.so'));lib.make_mesh.argtypes=[ctypes.POINTER(ctypes.c_double),ctypes.c_int];lib.make_mesh.restype=ctypes.c_void_p;lib.free_mesh.argtypes=[ctypes.c_void_p];lib.mesh_hit.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_int)]
class Body:
 def __init__(self,w):self.w=np.ascontiguousarray(w,dtype=np.float64);self.ptr=lib.make_mesh(self.w.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),len(w))
 def __del__(self):lib.free_mesh(self.ptr)
def hit(a,b):
 out=(ctypes.c_int*2)();return [int(i)for i in out]if lib.mesh_hit(a.ptr,b.ptr,out)else None
def enc(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 raise TypeError(type(x))
def gap(A,B):return float(np.maximum(A[0]-B[1],B[0]-A[1]).max())
def bb(w):return np.array([w.min(axis=tuple(range(w.ndim-1))),w.max(axis=tuple(range(w.ndim-1)))])
def desc(i,p):return dict(module_index0=i,name=p.name,note=p.note,head=bool(p.head))
signs=np.array([[x,y,z]for x in[-1,1]for y in[-1,1]for z in[-1,1]])
def rotate_bb(B,M):return bb((signs*(B[1]-B[0])/2+(B[1]+B[0])/2)@M.T)
base=c.module();N=len(base);new=[i for i,p in enumerate(base)if p.name=='60483.dat'];assert(N,len(new))==(167,4)
V={p.name:np.unique(c.mesh(p.name).reshape(-1,3),axis=0)*.4 for p in base}
def verts(p):return V[p.name]@p.rot.T+p.pos*.4
W=[c.world(p)for p in base];B=np.array([bb(w)for w in W])
# Direct source classification, checked at endpoints: head part motions comprise
# fixed bodies, crosshead translations, pivot rigid rotations, two links and pins.
# Analytical velocity derivation uses full natural range, not25-degree bounds.
m.OPEN_S=natural_s
end=c.module(natural_s);b0=m.CLAMP_BETA;b1=natural_beta
dmin=math.sqrt(m.LINK_L**2-(m.JAW_Y-m.JAW_A*math.sin(b0))**2)
xdot=m.JAW_A*math.sin(b1)+(m.JAW_Y-m.JAW_A*math.sin(b0))*m.JAW_A/dmin
classes={};speeds=np.zeros(N);dynamic=[]
for i,(a,b)in enumerate(zip(base,end)):
 sameR=np.allclose(a.rot,b.rot,atol=1e-10);sameP=np.allclose(a.pos,b.pos,atol=1e-10)
 if not a.head:continue
 if sameR and sameP:kind='fixed'
 elif a.note=='夹指连杆':
  kind='link';speeds[i]=.4*.5*(xdot+m.JAW_A)+float(np.linalg.norm(V[a.name],axis=1).max())*m.JAW_A/dmin
 elif not sameR:
  kind='jaw_pivot';sy=1 if a.pos[1]>0 else-1;piv=np.array([m.PIVOT_X+m.MODULE_DX,m.JAW_Y*sy,0.])*.4;R=m.rot_z((b1-b0)*sy)
  assert np.allclose(b.pos*.4,R@(a.pos*.4-piv)+piv,atol=1e-8) and np.allclose(b.rot,R@a.rot,atol=1e-8)
  speeds[i]=float(np.linalg.norm((verts(a)-piv)[:,:2],axis=1).max())
 elif np.allclose(b.pos-a.pos,[natural_s,0,0],atol=1e-8):kind='translation';speeds[i]=xdot*.4
 else:assert a.name=='3673.dat';kind='link_pin';speeds[i]=m.JAW_A*.4
 classes[i]=kind
 if kind!='fixed':dynamic.append(i)
assert speeds.max()<100
# These samples plus certified nearest-sample velocity dilation cover all beta.
def head_envelope(beta_hi,s_hi,steps=640):
 lo=np.full((N,3),np.inf);hi=-lo.copy();rmax=np.zeros(N)
 for k,beta in enumerate(np.linspace(b0,beta_hi,steps+1)):
  ss=min(s_hi,max(0.,m.cross_x_for_beta(beta)-m.CROSS_CLOSED_X));pp=c.module(ss)
  for i,p in enumerate(pp):
   if not p.head:continue
   w=verts(p);lo[i]=np.minimum(lo[i],w.min(0));hi[i]=np.maximum(hi[i],w.max(0));rmax[i]=max(rmax[i],float(np.linalg.norm(w[:,1:],axis=1).max()))
   if classes[i]=='fixed':assert np.allclose(w,verts(base[i]),atol=1e-7)
  if k%200==0:print('envelope',round(math.degrees(beta_hi),4),k,flush=True)
 pad=speeds*(beta_hi-b0)/(2*steps)+1e-9
 for i,p in enumerate(base):
  if p.head:lo[i]-=pad[i];hi[i]+=pad[i];rmax[i]+=pad[i]
 return np.stack([lo,hi],axis=1),rmax,pad
normal,normal_r,normal_pad=head_envelope(m.OPEN_BETA,ordinary_s)
natural,natural_r,natural_pad=head_envelope(b1,natural_s)
# Exact continuous nonhead bounds. Servo natural endpoint has an inverse-beta
# derivative singularity; no sampled derivative or finite bound is used there.
nonhead={};nonhead_methods={}
for i,(a,b)in enumerate(zip(base,end)):
 if a.head:continue
 sameR=np.allclose(a.rot,b.rot,atol=1e-10);sameP=np.allclose(a.pos,b.pos,atol=1e-10)
 if sameR and sameP:box=B[i];method='static exact vertex AABB'
 elif sameR and np.allclose(b.pos-a.pos,[natural_s,0,0],atol=1e-8):
  box=np.array([np.minimum(B[i,0],bb(verts(b))[0]),np.maximum(B[i,1],bb(verts(b))[1])]);method='monotone crosshead translation endpoint union'
 elif a.name=='41677.dat':
  pivot=a.pos*.4;rad=float(np.linalg.norm(verts(a)-pivot,axis=1).max());box=np.array([pivot-rad,pivot+rad]);method='full crank rotation circumsphere about constant pivot'
 elif a.note in['曲柄端轴','曲柄端内限位']:
  shiftlo=np.array([m.CRANK_C[0]+m.MODULE_DX-m.CRANK_R,m.CRANK_C[1]-m.CRANK_R,a.pos[2]])*.4
  shifthi=np.array([m.CRANK_C[0]+m.MODULE_DX+m.CRANK_R,m.CRANK_C[1]+m.CRANK_R,a.pos[2]])*.4
  local=V[a.name]@a.rot.T;box=np.array([local.min(0)+shiftlo,local.max(0)+shifthi]);method='full crank-circle center box plus exact fixed-orientation mesh bounds'
 elif a.note=='舵机连杆':
  low=np.array([.5*(m.CRANK_C[0]-m.CRANK_R+m.BLOCK_X_CLOSED)+m.MODULE_DX,.5*(m.CRANK_C[1]-m.CRANK_R+m.BLOCK_Y),a.pos[2]])*.4
  high=np.array([.5*(m.CRANK_C[0]+m.CRANK_R+m.BLOCK_X_CLOSED+natural_s)+m.MODULE_DX,.5*(m.CRANK_C[1]+m.CRANK_R+m.BLOCK_Y),a.pos[2]])*.4
  rad=float(np.linalg.norm(V[a.name],axis=1).max());box=np.array([low-rad,high+rad]);method='complete crank-circle and block-stroke midpoint envelope plus arbitrary-orientation link sphere'
 else:raise AssertionError(('unclassified nonhead',i,a.name,a.note))
 nonhead[i]=box;nonhead_methods[i]=method
# New-to-own-head proof, full natural opening; same-head common roll cancels.
# Mates are independently identified by native assembly and are not free-space.
mate_indices={163:[107,121,124,126],164:[99,121,125,127],165:[108,129,132,134],166:[98,129,133,135]}
local=[];mates=[];fail=[]
for i in new:
 for j,p in enumerate(base):
  if j==i or not p.head:continue
  if j in mate_indices[i]:
   assert classes[j]=='fixed'
   kind='fixation_friction_pin'if p.name=='2780.dat'else'root_axle'if p.name=='3707.dat'else'outer_half_bush_face'if p.name=='32123a.dat'else'inner_beam_face'
   mates.append(dict(bracket=i,other=desc(j,p),kind=kind,strict_surface_crossing=hit(Body(W[i]),Body(W[j])),aabb_gap_mm=gap(B[i],B[j]),relative_pose='Invariant throughout beta and full head roll'))
  else:
   g=gap(B[i],natural[j]);row=dict(bracket=i,other=desc(j,p),continuous_aabb_gap_mm=g);local.append(row)
   if g<=0:fail.append(row)
# Full arbitrary roll transforms a head part into a continuous cylinder envelope.
# Using its outer square AABB preserves sufficient separating axes; never certify
# a collision solely because envelopes overlap.
def fullroll_boxes(env,rmax):
 return {i:np.array([[env[i,0,0],-rmax[i],-rmax[i]],[env[i,1,0],rmax[i],rmax[i]]])for i,p in enumerate(base)if p.head}
def bracket_roll_box(i):
 r=float(np.linalg.norm(W[i][:,:,1:],axis=-1).max());return np.array([[B[i,0,0],-r,-r],[B[i,1,0],r,r]])
newboxes={(arm,i):rotate_bb(bracket_roll_box(i),M)for arm,M in m.ARM_ROT.items()for i in new}
allnh={(arm,i):rotate_bb(box,M)for arm,M in m.ARM_ROT.items()for i,box in nonhead.items()}
nhrows=[]
for (arm,i),box in newboxes.items():
 for (oa,j),ob in allnh.items():
  g=gap(box,ob);row=dict(arm=arm,bracket=i,other_arm=oa,other=desc(j,base[j]),continuous_gap_mm=g);nhrows.append(row)
  if g<=0:fail.append(row)
inter={}
for label,env,rr in [('normal25',normal,normal_r),('natural30_87225',natural,natural_r)]:
 heads={(arm,i):rotate_bb(box,M)for arm,M in m.ARM_ROT.items()for i,box in fullroll_boxes(env,rr).items()};out=[]
 for (arm,i),box in newboxes.items():
  for (oa,j),ob in heads.items():
   if arm==oa:continue
   g=gap(box,ob);row=dict(arm=arm,bracket=i,other_arm=oa,other=desc(j,base[j]),continuous_gap_mm=g);out.append(row)
   if g<=0:fail.append(row)
 inter[label]=dict(pair_count=len(out),minimum_gap_mm=min(q['continuous_gap_mm']for q in out),limiting=sorted(out,key=lambda q:q['continuous_gap_mm'])[:8])
# Exact fixture132 + retained59 from frozen original899 top-level assembly.
rows=json.loads((CAND/'source/assembly132.json').read_text());core=[m.Part(r['name'],r['color'],r['position_ldu'],r['rotation'],1,r['note'])for r in rows];roles=[r['role']for r in rows]
top=[l for l in c.files['machine_working-899.ldr']if l.startswith('1 ')];assert len(top)==899
for l in top[132:191]:
 a=l.split();v=np.array(a[2:14],float);core.append(m.Part(a[14],int(a[1]),v[:3],v[3:].reshape(3,3),1,'retained59'));roles.append('retained_base')
assert collections.Counter(roles)=={'moving':100,'fixed':30,'key':2,'retained_base':59}
# Original frame reference check: full frozen899's last708 are exact originals.
state={arm:(ordinary_s,50)for arm in m.ARMS};orig=m.build(state,with_cube=False)[64:]
assert top[191:]==[p.ldraw()for p in orig]
fixture=[]
for j,(p,role)in enumerate(zip(core,roles)):
 w=c.world(p);box=bb(w)
 if role=='moving':box[1]+=np.array([0,40,0]) # union of exact translational sweep
 # Keys are retained only in the upper state. Their extraction path is outside
 # scope; removed keys cannot interfere in subsequent mechanism motion.
 for (arm,i),nb in newboxes.items():
  localbox=rotate_bb(box,m.ARM_ROT[arm].T);dist=np.maximum(np.maximum(localbox[0],-localbox[1]),0);rho=float(np.linalg.norm(dist[1:]));r=float(np.linalg.norm(W[i][:,:,1:],axis=-1).max());g=max(B[i,0,0]-localbox[1,0],localbox[0,0]-B[i,1,0],rho-r);row=dict(arm=arm,bracket=i,external_index0=j,name=p.name,role=role,id=rows[j]['id']if j<132 else None,continuous_gap_mm=g,method='Axial interval or radial distance from exact swept AABB to full-roll outer cylinder')
  fixture.append(row)
  if g<=0:fail.append(row)
# Cube insertion/withdrawal vertical path is infinite along Y with X,Z in ±28.
# Every bracket axial coordinate has |axis|>=60.4mm, so all roll states and
# arbitrary opening are separated from this path by >=32.4mm.
cube_gap=min(min(abs(B[i,0,0]),abs(B[i,1,0]))-28 for i in new)
report=dict(status='PASS_NEW_BRACKET_FREE_SPACE'if not fail else'UNRESOLVED',source_sha256={str(p.relative_to(CAND)):hashlib.sha256(p.read_bytes()).hexdigest()for p in[CAND/'candidate.py',CAND/'source/baseline_model.py',CAND/'source/assembly132.json',CAND/'source/baseline-machine-899.mpd',CAND/'parts/60483.dat',CAND/'parts/60483s01.dat']},module_count=N,new_per_head=4,geometry_units_mm_per_ldu=.4,commanded_open_degrees=25,natural_endpoint=dict(stroke_ldu=natural_s,stroke_mm=natural_s*.4,beta_degrees=math.degrees(natural_beta),warning='Nominal kinematic endpoint only; normal command remains25degrees. Retained-pair overtravel screening is separate and does not certify arbitrary extended-range operation.'),velocity_proof=dict(min_link_horizontal_ldu=dmin,crosshead_speed_mm_per_beta_rad=xdot*.4,maximum_head_point_speed_mm_per_beta_rad=float(speeds.max()),per_part_speed_mm_per_beta_rad={str(i):float(speeds[i])for i in dynamic},classification=classes,derivation='Crosshead derivative <=A sin(beta_max)+j_y(beta_min) A/sqrt(L^2-j_y(beta_min)^2). Jaw body bound is maximum native vertex radius around pivot. Link angular rate<=A/d_min; link translation rate<=0.5*(crosshead_speed+A). Pin translation rate<=A. All in radians; multiply LDU by0.4.',normal_samples=641,natural_samples=641,normal_max_halfstep_dilation_mm=float(normal_pad.max()),natural_max_halfstep_dilation_mm=float(natural_pad.max()),nonhead_note='Exact geometric superset by full crank circle/circumspheres; no inverse-beta derivative at natural toggle.'),new_native_bounds_mm={i:B[i]for i in new},new_fullroll_outer_radius_mm=float(np.linalg.norm(W[new[0]][:,:,1:],axis=-1).max()),local_same_head=dict(nonmating_pair_count=len(local),minimum_continuous_gap_mm=min(q['continuous_aabb_gap_mm']for q in local),limiting=sorted(local,key=lambda q:q['continuous_aabb_gap_mm'])[:12],mating_pairs=mates),all_nonhead_all_arms=dict(pair_count=len(nhrows),minimum_continuous_gap_mm=min(q['continuous_gap_mm']for q in nhrows),limiting=sorted(nhrows,key=lambda q:q['continuous_gap_mm'])[:8],nonhead_bound_methods=nonhead_methods),interarm=inter,fixture132_plus_retained59=dict(part_count=191,roles=dict(collections.Counter(roles)),pair_count=len(fixture),minimum_continuous_gap_mm=min(q['continuous_gap_mm']for q in fixture),limiting=sorted(fixture,key=lambda q:q['continuous_gap_mm'])[:8],support_translation_mm=[0,40],coverage='Every support translation0…40mm and independent full360degree roll of each bracket simultaneously; upper keys checked at installed pose only.'),cube_vertical_insertion_and_withdrawal=dict(cube_size_mm=56,continuous_axis_gap_mm=cube_gap),route=dict(coverage='Proved as a subset of larger checked envelope',forward=['all arms50degree roll, jaws25degree open; vertical cube loading','FB roll50to0 while LR remain50/open','FB jaws close at0; LR remain50/open','remove both keys; lower support0to40mm','LR roll50to90 while FBclosed0','LR jaws close90'],reverse='Identical geometric state sets in reverse, with centered axis-aligned cube and upper support/locks reestablished before opening FB. Arbitrary solver terminal-pose approach is outside scope.'),unresolved=fail,limitations=['Incremental new-bracket free-space proof only: source-retained parts have unchanged geometry at same pose. This does not re-prove inherited retained-to-retained collisions or qualify extended-range operation.','Four native mating pairs per bracket are intentional joints; friction-pin strict triangle crossings are sent to separate native engagement audit. Face contacts, pin elastic interference and nominal axle fit receive no free-space clearance requirement.','New-bracket envelope proof covers even natural endpoint, but removal of the old30degree mechanical stop remains a functional change. Normal25degree command limit and physical calibration remain required.','No stiffness, grip force, tolerances, fatigue, assembly insertion path, key extraction trajectory, sensor/firmware implementation, or real-hardware qualification.','All meshes are nominal source meshes; floating arithmetic includes1e-9mm allowance, not formal interval arithmetic. The margins reported are large compared with that allowance.'],elapsed_s=time.time()-start)
(HERE/'motion-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,default=enc));np.savez_compressed(HERE/'continuous-envelopes.npz',normal=normal,natural=natural,normal_r=normal_r,natural_r=natural_r,normal_pad=normal_pad,natural_pad=natural_pad)
m.OPEN_S=ordinary_s
print(json.dumps({k:report[k]for k in['status','natural_endpoint','interarm','unresolved','elapsed_s']},indent=2,default=enc),flush=True)
print('minimum gaps',report['local_same_head']['minimum_continuous_gap_mm'],report['all_nonhead_all_arms']['minimum_continuous_gap_mm'],report['fixture132_plus_retained59']['minimum_continuous_gap_mm'],flush=True)
