"""Reproduce the retained-module overtravel screen; does not edit candidate/source.
Run PYTHONDONTWRITEBYTECODE=1 python screen.py. Units mm; IDs zero-based module list.
"""
from pathlib import Path
import sys,math,json,ctypes,itertools,time,hashlib,subprocess
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]));import candidate as c
START=c.m.OPEN_S;END=c.natural_stroke();B0=c.m.jaw_beta(START);B1=c.m.jaw_beta(END)
c.m.OPEN_S=END
P0=c.module(START);P1=c.module(END);N=len(P0)
assert N==167
moving=[i for i,(a,b) in enumerate(zip(P0,P1)) if not(np.allclose(a.pos,b.pos)and np.allclose(a.rot,b.rot))]
retained=list(range(163)); pairs=[(i,j)for i,j in itertools.combinations(retained,2)if i in moving or j in moving]
if not (HERE/'collision.so').exists():
 subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',str(HERE/'collision.cpp'),'-o',str(HERE/'collision.so')],check=True)
lib=ctypes.CDLL(str(HERE/'collision.so'))
lib.make_mesh.argtypes=[ctypes.POINTER(ctypes.c_double),ctypes.c_int];lib.make_mesh.restype=ctypes.c_void_p;lib.free_mesh.argtypes=[ctypes.c_void_p];lib.mesh_hit.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_int)]
class Body:
 def __init__(self,w):
  self.w=np.ascontiguousarray(w,dtype=np.float64);self.bounds=np.array([w.min((0,1)),w.max((0,1))]);self.ptr=lib.make_mesh(self.w.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),len(w))
 def __del__(self):lib.free_mesh(self.ptr)
def hit(a,b):
 out=(ctypes.c_int*2)();v=lib.mesh_hit(a.ptr,b.ptr,out)
 return {'triangle_ids':list(out),'triangles_mm':[a.w[out[0]].tolist(),b.w[out[1]].tolist()]}if v else None
static={i:Body(c.world(p))for i,p in enumerate(P0)if i not in moving}
records={};stats=[];count=121;t0=time.time()
# Inverse crank endpoint makes s(beta) exactly monotone over this range.
for n,b in enumerate(np.linspace(B0,B1,count)):
 s=min(END,c.m.cross_x_for_beta(b)-c.m.CROSS_CLOSED_X)
 pp=c.module(s);bb={**static,**{i:Body(c.world(pp[i]))for i in moving}}
 hits=[];overlap=0
 for i,j in pairs:
  a,z=bb[i],bb[j];gap=np.maximum(a.bounds[0]-z.bounds[1],z.bounds[0]-a.bounds[1])
  if gap.max()>1e-8:continue
  overlap+=1;q=hit(a,z)
  if q:
   key=f'{i}:{j}';rec=records.setdefault(key,{'pair':[i,j],'sample_indices':[],'baseline_25_hit':False,'first':None,'last':None})
   rec['sample_indices'].append(n);info={'sample_index':n,'beta_deg':math.degrees(b),'stroke_ldu':s,'head_roll_deg':0.0,'witness':q}
   if n==0:rec['baseline_25_hit']=True
   if rec['first']is None:rec['first']=info
   rec['last']=info;hits.append([i,j])
 stats.append({'sample_index':n,'beta_deg':math.degrees(b),'overlapping_AABB_pairs':overlap,'strict_crossings':hits})
 if n%10==0:print(n,round(math.degrees(b),6),'hits',len(hits),'unique',len(records),'elapsed',round(time.time()-t0,1),flush=True)
 report={'scope':'All retained local-module pairs where at least one part changes pose as opening extends 25deg to natural endpoint; excludes the four new60483 brackets (covered by separate parent audit). Head roll0; head-head results roll-invariant. Includes8 nonhead servo-moving parts and all other retained module geometry.','part_count':N,'retained_count':len(retained),'moving_indices':moving,'tested_pair_count':len(pairs),'sample_count':count,'beta_interval_deg':[math.degrees(B0),math.degrees(B1)],'stroke_interval_ldu':[START,END],'parts':[{'id':i,'name':p.name,'note':p.note,'head':p.head,'changes_with_opening':i in moving,'position_at25_ldu':p.pos.tolist(),'triangles':len(c.mesh(p.name))}for i,p in enumerate(P0)],'crossing_pairs':list(records.values()),'newly_observed_crossing_pairs':[q['pair']for q in records.values()if not q['baseline_25_hit']],'sample_stats':stats,'limitations':['Strict noncoplanar edge-interior/triangle-interior crossings only; no coplanar overlap or containment certification.','Finite beta samples are not continuous collision-free proof.','Retained fixed-fixed relative geometry is unchanged by this opening extension and is outside this screen.','Triangles are native recursive LDraw meshes; material deformation, manufacturing tolerance, compliance, load, shaft retention and actuator control limits not certified.'],'source_hashes':{str(p.relative_to(HERE.parents[1])):hashlib.sha256(p.read_bytes()).hexdigest()for p in [HERE.parents[1]/'candidate.py',HERE.parents[1]/'source/baseline_model.py',HERE.parents[1]/'source/baseline-machine-899.mpd',HERE/'collision.cpp']}}
 (HERE/'retained-overtravel-screen.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('DONE',len(records),'new',[q['pair']for q in records.values()if not q['baseline_25_hit']],flush=True)
