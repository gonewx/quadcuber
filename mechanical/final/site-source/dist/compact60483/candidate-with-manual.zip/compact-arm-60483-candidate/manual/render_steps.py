from pathlib import Path
import sys,copy,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from candidate import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgb
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
D=HERE/'manual/diagrams';D.mkdir(exist_ok=True)
old=BASE_MODULE(m.OPEN_S,0,False,True);new=module(m.OPEN_S)
TEAL='#009e9a';PINK='#d34588';GOLD='#e3a517';GRAY='#a8b3c1';BLUE='#2374c4'
def draw(ax,items,focus=(),removed=(),shifts={},limits=None,view=(20,-62),labels=True):
 for i,p in items:
  q=world(p)+np.array(shifts.get(i,[0,0,0]));q=q[:,:,[2,0,1]];q[:,:,2]*=-1
  color=TEAL if p.name=='60483.dat'else PINK if i in removed else GOLD if i in focus else {4:'#d65353',14:'#d8b238',0:'#546476',72:'#91a0ad',71:'#aeb9c6',1:'#708fad'}.get(p.color,GRAY)
  norm=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]); norm/=np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-10); shade=.45+.55*np.abs(norm@np.array([.38,-.53,.76])); colors=np.array(to_rgb(color))[None,:]*shade[:,None]; ax.add_collection3d(Poly3DCollection(q,facecolors=colors,edgecolors='none',linewidth=0,rasterized=True))
 if limits is None:limits=((-47,62),(-91,-27),(-60,60))
 ax.set(xlim=limits[0],ylim=limits[1],zlim=limits[2]);ax.set_box_aspect([b-a for a,b in limits],zoom=1.25);ax.view_init(*view);ax.set_axis_off()
 if labels:
  for txt,xyz in [('A (+Y)',(39,-65,-32)),('B (-Y)',(39,-65,32)),('+Z',(48,-54,0)),('-Z',(-43,-54,0))]: ax.text(*xyz,txt,color='#133c66',fontsize=11,fontweight='bold',bbox=dict(facecolor='white',alpha=.8,edgecolor='none',pad=2))
def fig1(name,title,items,focus=(),removed=(),shifts={},arrow=None,note='',limits=None):
 if len(sys.argv)>1 and name not in sys.argv[1:]:return
 audit_path=HERE/'manual/diagram-state-audit.json'; audit=json.loads(audit_path.read_text())if audit_path.exists()else {}; audit[name]={'parts':len(items),'60483_count':sum(p.name=='60483.dat'for _,p in items),'part_records':[p.ldraw()for _,p in items],'translated_indices':list(shifts)}; audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
 fig=plt.figure(figsize=(10,6.3),facecolor='white');ax=fig.add_subplot(111,projection='3d');draw(ax,items,focus,removed,shifts,limits,labels=name in ['identify','root_done','second_root','complete'])
 if arrow:
  start,vec=arrow; a=np.array(start)[[2,0,1]];a[2]*=-1;v=np.array(vec)[[2,0,1]];v[2]*=-1;ax.quiver(*a,*v,color='#134a80',linewidth=3,arrow_length_ratio=.2)
 fig.suptitle(title,fontsize=16,x=.5,y=.97,fontweight='bold');fig.text(.5,.05,note,ha='center',fontsize=10);fig.subplots_adjust(left=0,right=1,bottom=.09,top=.92);fig.savefig(D/(name+'.png'),dpi=155);plt.close(fig);print(name,flush=True)
# Entire head context; not simplified stand-ins.
head=[(i,p)for i,p in enumerate(old)if p.head and p.pos[0]>-235]
fig1('identify','A / B root identification | full LDraw meshes',head,focus=[121,124,125,128,131,136,139,140,143,146],removed=[132,133,134,147,148,149],note='Gold: retain roots / retainers / fixation pins. Pink: REMOVE stop assemblies. A = local +Y; B = local -Y.')
fig1('rollback','22 | Original arrangement to RESTORE during rollback',head,focus=[121,124,125,128,131,136,139,140,143,146],removed=[132,133,134,147,148,149],note='Pink: RESTORE original stop assemblies during rollback. Gold: retain root axles, root retainers and fixation pins.')
fig1('overview','60483 candidate | complete head context',[(i,p)for i,p in enumerate(new)if p.head],limits=((-70,70),(-170,-15),(-68,68)),note='Teal: four new 60483. Other head parts retained. CAD review only; support fixtures not modeled.')
fig1('stop1','04 | Remove FIRST stop half bush',head,removed=[134],shifts={134:[0,0,24]},arrow=([-48,48,32],[0,0,24]),note='Pink: STOP half bush only. Pull outward +Z; both ROOT half bushes remain installed.')
fig1('stop2','05 | Withdraw stop axle from opposite end',[(i,p)for i,p in head if i!=134],removed=[132,133],shifts={132:[0,0,-72],133:[0,0,-72]},arrow=([-48,48,-32],[0,0,-40]),limits=((-115,50),(-91,-27),(-60,60)),note='Pull -Z from the end still carrying a STOP half bush. Direction sketch; actual access remains unverified.')
noStop=[(i,p)for i,p in head if i not in [132,133,134]]
fig1('root_open','06 | Open ONE root end only',noStop,focus=[121,124],removed=[125],shifts={125:[0,0,25]},arrow=([-64,32,32],[0,0,22]),note='Root A +Z half bush is temporarily removed. Keep the -Z retainer and independent support in place.')
noHalf=[(i,p)for i,p in noStop if i!=125]
fig1('outer_off','07 | Slide off OUTER thin L bracket',noHalf,removed=[130],shifts={130:[0,0,25]},arrow=([-64,32,32],[0,0,23]),note='Remove outer 32056 along +Z. Root axle and 2780 stay in place; do not twist the bracket.')
noOuter=[(i,p)for i,p in noHalf if i!=130]
fig1('pair_off','08 | Slide off INNER thin L bracket',noOuter,removed=[129],focus=[121,131],shifts={129:[0,0,32]},arrow=([-64,32,30],[0,0,27]),note='Remove inner 32056 along +Z. Gold: the TWO retained connection points, 8 mm apart.')
newA=next(p for p in new if p.name=='60483.dat'and p.pos[1]>0 and p.pos[2]>0)
base=[(i,p)for i,p in noOuter if i!=129]+[(900,newA)]
fig1('new_align','09 | Cross hole to ROOT; round hole to 2780',base,focus=[121,131],shifts={900:[0,0,27]},arrow=([-64,32,56],[0,0,-24]),note='Teal: 60483 at exploded position. Slide inward -Z; the offset is illustration spacing, not a fitted gap.')
fig1('new_in','10 | Seat both connections together',base,focus=[121,131],note='60483 cross-bore engagement: 8 mm. 2780 engages 8 mm in bracket + 8 mm in inner beam.')
fig1('retained','11 | Refit SAME root half bush',base+[(125,old[125])],focus=[125],arrow=([-64,32,55],[0,0,-20]),note='Do not squeeze the jaw shut. Exact 64 mm modeled stack has zero nominal axial reserve.')
# Full candidate for root completion and second root context.
nh=[(i,p)for i,p in enumerate(new)if p.head and p.pos[0]>-235]
aroot=[(i,p)for i,p in head if i not in [126,127,129,130,132,133,134]]+[(900+i,p)for i,p in enumerate(new)if p.name=='60483.dat'and p.pos[1]>0]
fig1('root_done','12 | Root A complete; root B remains unchanged',aroot,note='At -Z end: remove outward -Z, install inward +Z. A is retained at BOTH ends before work starts on B.')
fig1('second_root','14 | Remove root B STOP assembly; retain both ROOT ends',aroot,removed=[147,148,149],shifts={147:[0,0,-72],148:[0,0,-72],149:[0,0,24]},arrow=([-48,-48,-32],[0,0,-40]),limits=((-115,60),(-91,-27),(-60,60)),note='Root B = local -Y. Keep root A completed and retained. Pink: B stop axle and TWO stop half bushes.')
bside=[(i,p)for i,p in aroot if i not in [144,145,147,148,149]]+[(990,p)for p in new if p.name=='60483.dat'and p.pos[1]<0 and p.pos[2]>0]
fig1('second_side','15 | Root B +Z side complete; -Z side is still old',bside,focus=[140],note='Refit B +Z root half bush before opening B -Z. A has two new brackets; B currently has one.')
fig1('complete','16-17 | Four new brackets per head',nh,note='Per head retain: 2 root axles, 4 full bushes, 4 root half bushes, 4 fixation pins. Stop parts are absent.')
# Exact root stack with separated actual parts to expose hole shapes.
stack=[(i,p)for i,p in enumerate(new)if (p.name in ['60483.dat','3707.dat','3713.dat','32123a.dat','32524.dat'] and abs(p.pos[1]-80)<1e-5)]
# Add inner beams from original nearest root region, not fabricated proxy parts.
inners=[(i,p)for i,p in enumerate(new)if p.head and i in [99,107]]
fig1('stack','Root-stack reference: 4+8+8+8+8+8+8+8+4 = 64 mm',stack+inners,limits=((-39,39),(-94,-34),(-51,0)),note='Outside half bush | bracket | inner beam | full bush | jaw | full bush | inner beam | bracket | half bush')
fig=plt.figure(figsize=(10,6.3),facecolor='white')
for k,s in enumerate([0,m.OPEN_S]):
 ax=fig.add_subplot(1,2,k+1,projection='3d');pp=module(s);draw(ax,[(i,p)for i,p in enumerate(pp)if p.head and p.pos[0]>-235]);ax.set_title(('Closed ~3.8417 degrees','NORMAL maximum 25 degrees')[k],fontsize=12)
fig.suptitle('19 | Jaw opening is NOT the whole-head rotation angle',fontsize=15,fontweight='bold');fig.text(.5,.05,'Do not use the 30.872-degree natural endpoint as a stop, homing reference or powered command.',ha='center',fontsize=10);fig.savefig(D/'opening.png',dpi=155);plt.close(fig)
# Inventory real mesh objects, no illustrative substitute geometry.
fig=plt.figure(figsize=(10,6.3),facecolor='white')
for k,(name,title)in enumerate([('60483.dat','ADD 4 x 60483 / head'),('32056.dat','REMOVE 8 x 32056 / head'),('3707.dat','REMOVE 2 x STOP axle / head'),('32123a.dat','REMOVE 4 x STOP half bush / head')]):
 ax=fig.add_subplot(2,2,k+1,projection='3d');meshdata=mesh(name)*.4;lo=meshdata.min((0,1));hi=meshdata.max((0,1));mid=(lo+hi)/2;size=max(hi-lo)*.65
 nn=np.cross(meshdata[:,1]-meshdata[:,0],meshdata[:,2]-meshdata[:,0]);nn/=np.maximum(np.linalg.norm(nn,axis=1,keepdims=True),1e-10);cc=np.array(to_rgb(TEAL if k==0 else PINK))[None,:]*(.45+.55*np.abs(nn@np.array([.38,-.53,.76])))[:,None];ax.add_collection3d(Poly3DCollection(meshdata,facecolors=cc,edgecolors='none'));ax.set(xlim=(mid[0]-size,mid[0]+size),ylim=(mid[1]-size,mid[1]+size),zlim=(mid[2]-size,mid[2]+size));ax.set_box_aspect((1,1,1));ax.view_init(22,-55);ax.set_axis_off();ax.set_title(title,fontsize=11)
fig.suptitle('02 | Parts delta only: -10 per head, -40 for four heads',fontsize=15,fontweight='bold');fig.text(.5,.035,'Scale differs by panel. Root axles and root half bushes have the same IDs as stop parts: identify by POSITION.',ha='center',fontsize=10);fig.savefig(D/'inventory.png',dpi=155);plt.close(fig)
