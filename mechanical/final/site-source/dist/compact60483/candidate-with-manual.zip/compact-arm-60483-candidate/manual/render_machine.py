from pathlib import Path
import sys,json,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from candidate import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgb
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
manifest=json.loads((HERE/'candidate-manifest.json').read_text())
for key in ['loading-all50','both-held']:
 lines=(HERE/manifest[key]['file']).read_text().split('\n0 FILE ')[0].splitlines();parts=[]
 for l in lines:
  s=l.split()
  if s and s[0]=='1':
   v=np.array(s[2:14],float);parts.append(m.Part(s[14],int(s[1]),v[:3],v[3:].reshape(3,3),0))
 fig=plt.figure(figsize=(10,7),facecolor='white');ax=fig.add_subplot(111,projection='3d')
 for p in parts:
  q=world(p)[:,:,[0,2,1]];q[:,:,2]*=-1;color='#009e9a'if p.name=='60483.dat'else {4:'#d65353',14:'#d8b238',0:'#546476',72:'#91a0ad',71:'#aeb9c6',1:'#708fad'}.get(p.color,'#b0bac5');n=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-10);c=np.array(to_rgb(color))[None,:]*(.45+.55*np.abs(n@np.array([.38,-.53,.76])))[:,None];ax.add_collection3d(Poly3DCollection(q,facecolors=c,edgecolors='none',rasterized=True))
 ax.set(xlim=(-220,220),ylim=(-220,220),zlim=(-175,90));ax.set_box_aspect((440,440,265),zoom=1.4);ax.view_init(28,-56);ax.set_axis_off()
 for txt,p in [('R +X',(215,0,0)),('L -X',(-215,0,0)),('F +Z',(0,215,0)),('B -Z',(0,-215,0))]:ax.text(*p,txt,fontsize=12,color='#174476')
 fig.suptitle('60483 candidate | '+key+' | '+str(len(parts))+' parts',fontsize=16,fontweight='bold');fig.text(.5,.04,'Actual embedded LDraw meshes. Teal = 60483. No cube / support fixture modeled; no physical acceptance.',ha='center',fontsize=10);fig.savefig(HERE/'manual/diagrams'/('machine-'+key+'.png'),dpi=145);plt.close(fig);print(key,flush=True)
