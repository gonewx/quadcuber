from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.colors import HexColor
from PIL import Image
H=Path(__file__).resolve().parent;G=json.loads((H/'guide.json').read_text())
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
W,HGT=595.276,841.89
c=canvas.Canvas(str(H/'manual60483.pdf'),pagesize=(W,HGT));c.setTitle(G['title']);c.setAuthor('60483 candidate design review')
P=ParagraphStyle('p',fontName='STSong-Light',fontSize=12.5,leading=20,wordWrap='CJK',textColor=HexColor('#183046'))
B=ParagraphStyle('b',parent=P,fontSize=14,leading=22)
T=ParagraphStyle('t',parent=P,fontSize=23,leading=31)
S=ParagraphStyle('s',parent=P,fontSize=10,leading=15,textColor=HexColor('#536779'))
page=0
checks=[]
def para(text,y,style=P,x=40,width=515):
 text=text.replace("−","-").replace("□","[ ]");p=Paragraph(text,style);w,h=p.wrap(width,760);p.drawOn(c,x,y-h);return y-h-9

def start(label):
 global page
 page+=1;c.setFillColor(HexColor('#133f63'));c.rect(0,HGT-38,W,38,fill=1,stroke=0);c.setFillColor(HexColor('#ffffff'));c.setFont('STSong-Light',10);c.drawString(40,HGT-25,'60483候选 / 改装补充说明书');c.drawRightString(W-40,HGT-25,label)
 c.setFillColor(HexColor('#536779'));c.setFont('STSong-Light',9);c.drawString(40,24,'设计审阅；装配路径、实体保持与带电动作未放行');c.drawRightString(W-40,24,str(page))
def img(path,y,width=515):
 im=Image.open(path);h=width*im.height/im.width;c.drawImage(str(path),40,y-h,width,h,preserveAspectRatio=True,mask='auto');return y-h-7
start('R1 / 2026-10-07')
y=para('60483根部支架候选<br/>22步改装补充说明书',775,T)
y=para('每头8片32056换4件60483；四头899 → 859件',y,B)
y=para('132件支承与59件底盘不变。原支承80步说明继续适用；本册只补充机械头改装。',y)
c.setFillColor(HexColor('#fff0d1'));c.roundRect(36,y-112,523,112,8,fill=1,stroke=0)
y=para('未通过实体装配或带电试机验收。<br/>仅验证名义最终配合；拆装插拔路径未做连续碰撞验证，也未经实体验证。根轴64mm名义叠层零余量，正常夹指仍限25°，原8墙脚销HOLD保留。',y-12,B,x=48,width=491)-16
y=img(H/'diagrams/machine-loading-all50.png',y)
y=para('图示使用真实内嵌LDraw零件网格。青绿为60483新件；粉红为本步拆下件；金色为强调保留件。爆炸间距不代表装配间隙，箭头只说明名义轴向方向。',y,S)
y=para('配套私人页面：<link href="https://quadcuber-shared-chassis-192.d41647284.chatgpt.site/compact60483-guide.html" color="#075ba3">打开本册与一致的候选整机视图</link>',y,S)
checks.append(dict(page=page,last_y=y));c.showPage()
for s in G['steps']:
 start(str(s['id']).zfill(2)+' / 22')
 y=para(str(s['id']).zfill(2)+'　'+s['title'],775,T)
 y=para(s['parts'],y,B)
 y=img(H/s['image'],y,515)
 # all images have a readable title; captions stay in main text too.
 for i,line in enumerate(s['instructions'],1):y=para(str(i)+'. '+line,y,P)
 y=para('核对：'+s['check'],y,B)
 if s['id']==20:y=para('<link href="https://quadcuber-shared-chassis-192.d41647284.chatgpt.site/compact60483-operation.html" color="#075ba3">打开配套候选整机／操作关系网页（七个模型）</link>',y,S)
 if y<45:raise RuntimeError('Page overflow: '+str(page)+' y='+str(y))
 checks.append(dict(page=page,step=s['id'],last_y=y));c.showPage()
start('核对记录 / 来源')
y=para('最终清点与待验证记录',775,T)
for line in ['新增：每头4件60483，四头16件。','拆下：每头8片32056、2根3707挡轴、4只32123a挡轴半套；四头分别32、8、16件。','本次涉及的保留件：每头2根3707根轴、4只3713根轴整套、4只32123a根轴外半套、4枚2780固定销；这不是全头总库存。','整机：上位带工作锁销859件；下位移除两工作锁销857件。支承132件、底盘59件不变。','逐头记录：R________　L________　F________　B________','待验证：装配路径、根轴自由运动与防脱、夹头刚度、加载下垂、销尖卡滞、两锁销插拔、手／工具空间、实际控制联锁。','发现问题：________________________________________________','未叠加11478、18654简化、原8墙脚销改动或固件／GitHub修改。']:
 y=para(line,y)
y=para('证据与复现',y-12,B)
for line in ['候选模型：models/内7个整机状态与2个单头状态；每个文件哈希见candidate-manifest.json。','接合审核：structure/engagement_audit.json。运动证据：motion/；异常25°以上保留件筛查仅LIMITED。','说明源：manual/guide.json、make_steps.py、render_steps.py、render_machine.py、build_pdf.py。静态图与PDF均可复现。','冻结model.py SHA256：'+G['source_sha256'],'原始输入包SHA256：'+G['input_package_sha256'],'LDraw 60483官方作者Philo、子零件jb70，CC BY 4.0。其余嵌入零件保留各自作者及许可证。','参考：github.com/gonewx/quadcuber/blob/main/tools/lego/v4/model.py；library.ldraw.org/library/official/parts/60483.dat。来源核对日期2026-10-07。']:
 y=para(line,y,S)
checks.append(dict(page=page,last_y=y));c.showPage();c.save()
(H/'pdf-layout-check.json').write_text(json.dumps(dict(pages=page,checks=checks),indent=2));print('PDF',page,'pages; lowest text y',min(x['last_y']for x in checks))
# Editable, searchable text alongside JSON.
out=['# '+G['title'],'','设计候选；不可据此带电试机。','']
for s in G['steps']:
 out+=['## '+str(s['id']).zfill(2)+' '+s['title'],s['parts'],'']+s['instructions']+['','核对：'+s['check'],'']
(H/'manual60483.md').write_text('\n'.join(out))
