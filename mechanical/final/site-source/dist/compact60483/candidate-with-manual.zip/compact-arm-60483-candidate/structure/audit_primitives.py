"""Self-contained primitive and triangle helpers.
Adapted from combined-joints/audit_common.py extraction; not previous results.
Adds axlehol4.dat required by 60483 and records every expected crossing.
"""

import numpy as np

import functools

import candidate as c

def children(n):
 for i,line in enumerate(c.files[c.resolve(n)]):
  s=line.split()
  if s and s[0]=="1":
   a=np.array(s[2:14],float)
   yield i," ".join(s[14:]).replace("\\","/").lower(),a[:3],a[3:].reshape(3,3)

@functools.lru_cache(None)
def local_ports(name):
 out=[];mouths=[]
 def add(kind,a,b,path,pr):
  if np.linalg.norm(b-a)>1e-8:out.append(dict(kind=kind,a=a,b=b,path=path,primitive=pr))
 def walk(n,M,P,path):
  for k,c,t,r in children(n):
   T=P+M@t; R=M@r; pa=path+f'/{n}:{k}:{c}'
   if c.startswith('confric') or c.startswith('connect') or c=='axle.dat':
    continue  # Solid pin/axle primitives are not host bores, even where their outside diameter is6LDU.
   elif c.endswith('32013s01.dat'):
    add('blind_cross_socket',T+R@np.array([0,0,10]),T+R@np.array([0,0,30]),pa,c)
   elif c in ['axl2hole.dat','axlehol5.dat','axlehol4.dat']:
    add('cross_bore',T,T+R[:,1],pa,c)
   elif c=='axl2hol8.dat':
    add('cross_bore_inner',T,T+R[:,1],pa,c)
   elif c in ['peghole.dat','peghole5.dat','npeghol20.dat']:
    mouths.append((T,R[:,1]/np.linalg.norm(R[:,1]),pa))
   elif c in ['2-4cyli.dat','4-4cyli.dat'] and abs(np.linalg.norm(R[:,0])-8)<1e-3 and abs(np.linalg.norm(R[:,2])-8)<1e-3 and abs(np.linalg.norm(R[:,1])-2)<1e-3:
    ma=R[:,1]/np.linalg.norm(R[:,1]);mouths.extend([(T,ma,pa),(T+R[:,1],ma,pa)])
   elif c=='4-4cyli.dat' and abs(np.linalg.norm(R[:,0])-6)<1e-3 and abs(np.linalg.norm(R[:,2])-6)<1e-3:
    add('round_bore_core',T,T+R[:,1],pa,c)
   else:walk(c,R,T,pa)
 walk(name,np.eye(3),np.zeros(3),'')
 # Extend a round core only when an actual peghole mouth is collinear within2LDU of its endpoint.
 for p in out:
  if p['kind']!='round_bore_core':continue
  ax=(p['b']-p['a']);ax/=np.linalg.norm(ax)
  a,b=sorted([p['a']@ax,p['b']@ax]); accepted=[]
  for pt,ma,path in mouths:
   if abs(abs(ma@ax)-1)>1e-5 or np.linalg.norm(np.cross(pt-p['a'],ax))>1e-4:continue
   t=pt@ax
   if abs(t-a)<=2.0001 or abs(t-b)<=2.0001:accepted.append((t,path))
  if accepted:
   old=p['a'].copy();orig=old@ax
   aa=min(a,*[q[0]for q in accepted]);bb=max(b,*[q[0]for q in accepted]);p['a']=old+(aa-orig)*ax;p['b']=old+(bb-orig)*ax;p['mouth_paths']=[q[1]for q in accepted];p['kind']='round_bore_full_depth'
 unique=[]
 for p in out:
  ax=p['b']-p['a'];p['axis']=ax/np.linalg.norm(ax);p['center']=(p['a']+p['b'])/2
  if any(np.linalg.norm(p['center']-q['center'])<1e-5 and abs(abs(p['axis']@q['axis'])-1)<1e-5 and abs(np.linalg.norm(ax)-np.linalg.norm(q['b']-q['a']))<1e-5 for q in unique):continue
  unique.append(p)
 return unique

def edge_hits(P,Q,T,eps=1e-7):
 D=Q-P;E1=T[:,1]-T[:,0];E2=T[:,2]-T[:,0];H=np.cross(D,E2);det=np.einsum('ij,ij->i',E1,H);good=abs(det)>eps
 inv=np.zeros_like(det);inv[good]=1/det[good];S=P-T[:,0];u=np.einsum('ij,ij->i',S,H)*inv;QQ=np.cross(S,E1);v=(QQ@D)*inv;t=np.einsum('ij,ij->i',E2,QQ)*inv
 good&=(u>eps)&(u<1-eps)&(v>eps)&(u+v<1-eps)&(t>eps)&(t<1-eps)
 ids=np.flatnonzero(good)
 return [(int(j),P+t[j]*D)for j in ids]

def strict_hit(A,B,allowed=None):
 blo=B.min(1);bhi=B.max(1);mating=[]
 for i,a in enumerate(A):
  ids=np.flatnonzero(np.all(blo<=a.max(0),axis=1)&np.all(bhi>=a.min(0),axis=1))
  if not len(ids):continue
  for k in range(3):
   for jj,pt in edge_hits(a[k],a[(k+1)%3],B[ids]):
    j=int(ids[jj]);w=dict(triangles=[int(i),j],point=pt.tolist())
    if allowed and allowed(pt):
     mating.append(w)
    else:return w,mating
  for k in range(3):
   PP=B[ids,k];QQ=B[ids,(k+1)%3];DD=QQ-PP;ee1=a[1]-a[0];ee2=a[2]-a[0];HH=np.cross(DD,ee2);det=HH@ee1;ok=abs(det)>1e-7;inv=np.zeros_like(det);inv[ok]=1/det[ok];SS=PP-a[0];uu=np.einsum('ij,ij->i',SS,HH)*inv;XX=np.cross(SS,ee1);vv=np.einsum('ij,ij->i',DD,XX)*inv;tt=(XX@ee2)*inv
   ok&=(uu>1e-7)&(uu<1-1e-7)&(vv>1e-7)&(uu+vv<1-1e-7)&(tt>1e-7)&(tt<1-1e-7)
   for jj in np.flatnonzero(ok):
    pt=PP[jj]+tt[jj]*DD[jj];w=dict(triangles=[int(i),int(ids[jj])],point=pt.tolist())
    if allowed and allowed(pt):
     mating.append(w)
    else:return w,mating
 return None,mating
