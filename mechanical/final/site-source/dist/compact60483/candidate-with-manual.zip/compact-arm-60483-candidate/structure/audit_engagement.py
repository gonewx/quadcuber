"""Independent read-only nominal LDraw audit for the frozen 60483 candidate.
Outputs only in this directory. Does not reuse prior audit conclusions.
"""
from pathlib import Path
import sys, ast, functools, hashlib, json, math
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import candidate as c
m=c.m
EPS=1e-6

def norm(n):return n.replace('\\','/').lower()
def children(n):
 for i,line in enumerate(c.files[c.resolve(n)]):
  s=line.split()
  if s and s[0]=='1':
   a=np.array(s[2:14],float)
   yield i,norm(' '.join(s[14:])),a[:3],a[3:].reshape(3,3)

# Self-contained helper copy is shipped with this audit.
from audit_primitives import local_ports,strict_hit

def jsonable(o):
 if isinstance(o,np.ndarray):return o.tolist()
 if isinstance(o,np.generic):return o.item()
 raise TypeError(type(o).__name__)
def dump(n,d):(HERE/n).write_text(json.dumps(d,indent=2,default=jsonable))
def desc(pp,i):
 p=pp[i]
 return dict(index=i,name=p.name,note=p.note,position_ldu=p.pos,rotation=p.rot)
def worldports(p):
 hs=[]
 for h in local_ports(p.name):
  a=(p.rot@h['a']+p.pos)*.4;b=(p.rot@h['b']+p.pos)*.4
  hs.append(dict(h,a=a,b=b,axis=(b-a)/np.linalg.norm(b-a),center=(a+b)/2,length_mm=np.linalg.norm(b-a)))
 return hs

def common_axis_distance(p,h):
 ax=p.rot[:,0]
 return np.linalg.norm(np.cross(h['center']-.4*p.pos,ax)),abs(abs(ax@h['axis'])-1)

def joint(p,h):
 ax=p.rot[:,0];W=c.world(p);ss=np.array([(W@ax).min(),(W@ax).max()]);hs=np.sort([h['a']@ax,h['b']@ax]);eng=min(ss[1],hs[1])-max(ss[0],hs[0]);off,angular=common_axis_distance(p,h)
 return dict(shaft_span_mm=ss,port_span_mm=hs,engagement_mm=eng,port_length_mm=h['length_mm'],full_depth=eng>=h['length_mm']-1e-6,offset_mm=off,axis_error=angular,kind=h['kind'],primitive=h['primitive'],source_path=h['path'])

@functools.lru_cache(None)
def triangle_sources(name):
 out=[];section='body'
 for k,line in enumerate(c.files[c.resolve(name)]):
  ss=line.split()
  if line.startswith('0 Friction'):section='friction_ribs'
  if not ss:continue
  if ss[0]=='1':
   child=norm(' '.join(ss[14:]))
   for row in triangle_sources(child):
    out.append(dict(path=f'{name}:{k+1}/'+row['path'],section='friction_ribs' if section=='friction_ribs' else row['section']))
  elif ss[0]in ['3','4']:
   for tri in range(1 if ss[0]=='3' else 2):out.append(dict(path=f'{name}:{k+1}:triangle{tri}',section=section))
 assert len(out)==len(c.mesh(name))
 return out

def immutable_hashes():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'candidate.py',*sorted((ROOT/'parts').glob('*')),*sorted((ROOT/'source').glob('*'))] if p.is_file()}
before=immutable_hashes()
pp=c.module(on_base=False);base=c.BASE_MODULE(on_base=False)
newidx=[i for i,p in enumerate(pp) if p.name=='60483.dat']
roots=[i for i,p in enumerate(pp)if p.name=='3707.dat' and p.head]
fixpins=[i for i,p in enumerate(pp) if p.note=='限位支架固定销']
assert len(newidx)==4 and len(roots)==2 and len(fixpins)==4
native=local_ports('60483.dat')
assert len(native)==2
assert any(h['kind']=='cross_bore' and np.allclose(h['center'],[0,0,0]) and np.isclose(np.linalg.norm(h['b']-h['a']),20) for h in native)
assert any(h['kind']=='round_bore_full_depth' and np.allclose(h['center'],[0,0,20]) and np.isclose(np.linalg.norm(h['b']-h['a']),20)for h in native)

def key(p):return (p.name,p.color,p.note,tuple(p.pos.round(8)),tuple(p.rot.round(8).flat),p.head)
removed=[p for p in base if key(p)not in {key(q)for q in pp}]
retained=[p for p in pp if p.name!='60483.dat']
assert len(base)-len(pp)==10 and len(removed)==14
assert all(key(p)in {key(q)for q in base}for p in retained)
assert all(p.note in ['开限位挡轴','开限位挡轴轴套','限位支架']for p in removed)

results=[];shaft_joint_rows=[];surface_rows=[]
for i in newidx:
 p=pp[i];hs=worldports(p);cross=next(h for h in hs if h['kind']=='cross_bore');roundh=next(h for h in hs if h['kind'].startswith('round'))
 matches=[]
 for h,ids in [(cross,roots),(roundh,fixpins)]:
  mi=[k for k in ids if all(v<1e-6 for v in common_axis_distance(pp[k],h)) and joint(pp[k],h)['engagement_mm']>1e-6]
  assert len(mi)==1
  s=mi[0];j=joint(pp[s],h);assert j['full_depth'];matches.append((h,s,j))
 # Independently recover each actual old pair from its old cross/round
 # primitive centers, rather than trusting the candidate's placement formula.
 oldpair=[]
 for oi,op in enumerate(base):
  if op.name!='32056.dat' or op.note!='限位支架':continue
  oh=worldports(op)
  oc=[h for h in oh if h['kind']=='cross_bore' and np.linalg.norm(h['center']-cross['center'])<2.000001]
  orn=[h for h in oh if h['kind'].startswith('round') and np.linalg.norm(h['center']-roundh['center'])<2.000001]
  if len(oc)==1 and len(orn)==1:oldpair.append((oi,oc[0],orn[0]))
 assert len(oldpair)==2
 assert np.allclose(sum(q[1]['center'] for q in oldpair)/2,cross['center'])
 assert np.allclose(sum(q[2]['center'] for q in oldpair)/2,roundh['center'])
 assert np.isclose(np.linalg.det(p.rot),1)
 oldfacepoints=np.concatenate([[q[1]['a'],q[1]['b']]for q in oldpair])
 oldspan=np.sort([np.min(oldfacepoints@cross['axis']),np.max(oldfacepoints@cross['axis'])])
 newsp=np.sort([cross['a']@cross['axis'],cross['b']@cross['axis']])
 assert np.allclose(oldspan,newsp)
 crossshaft=matches[0][1];pin=matches[1][1]
 # Exact phase in the plane perpendicular to the cross axle.
 phase=np.abs(p.rot[:,0]@pp[crossshaft].rot[:,1]);assert min(abs(phase),abs(phase-1))<1e-7
 # The same two shaft axes occur in the retained adjacent beam.
 beam_matches=[]
 for bi,b in enumerate(pp):
  if b.note not in ['内侧长段','内侧短段']:continue
  bj=[]
  for hh in worldports(b):
   for si in [crossshaft,pin]:
    if all(v<1e-6 for v in common_axis_distance(pp[si],hh)):
     jj=joint(pp[si],hh)
     if jj['engagement_mm']>1e-6:bj.append((si,hh,jj))
  if {q[0]for q in bj}=={crossshaft,pin}:beam_matches.append((bi,bj))
 assert len(beam_matches)==1
 bi,bj=beam_matches[0]
 assert all(x[2]['full_depth']for x in bj)
 # The pin collar sits at the shared bracket/inner-beam face; both recesses
 # must occupy its +/-2 LDU depth. This check does not waive the entire pin.
 ax=pp[pin].rot[:,0];origin=.4*pp[pin].pos
 pin_whole=c.world(pp[pin]);local=(pin_whole-origin)@pp[pin].rot
 collar=local[np.all(np.abs(local[:,:,0])<=.80001,axis=1)]
 collar_t=collar[:,:,0];collar_r=np.linalg.norm(collar[:,:,1:],axis=2)
 bracket_span=np.sort([(cross['a']@ax),(cross['b']@ax)])
 bph=next(h for si,h,j in bj if si==pin)
 bspan=np.sort([bph['a']@ax,bph['b']@ax]);pspan=np.sort([roundh['a']@ax,roundh['b']@ax]);t0=origin@ax
 shared=min(abs(pspan-t0));shared2=min(abs(bspan-t0));assert shared<1e-6 and shared2<1e-6
 assert np.isclose(min(pspan[1],bspan[1])-max(pspan[0],bspan[0]),0,atol=1e-7)
 # Compare collar vertices with the same16-sided recess in the bracket frame.
 pin_vertices=pin_whole.reshape(-1,3)
 local_vertices=(pin_vertices-origin)@pp[pin].rot
 collar_vertices=pin_vertices[np.abs(local_vertices[:,0])<=.80001]
 brlocal=(collar_vertices-p.pos*.4)@p.rot
 xz=brlocal[:,[0,2]]-np.array([0.,8.])
 aa=(np.arange(16)+.5)*2*np.pi/16
 normal2=np.stack([np.cos(aa),np.sin(aa)],axis=1)
 collar_polygon_excess=(xz@normal2.T-3.2*np.cos(np.pi/16)).max()
 assert collar_polygon_excess<.001
 row=dict(replaced_old_pair=[desc(base,q[0])for q in oldpair],old_pair_centers_and_outer_faces_match=True,bracket=desc(pp,i),root=desc(pp,crossshaft),pin=desc(pp,pin),inner_beam=desc(pp,bi),hole_spacing_mm=np.linalg.norm(roundh['center']-cross['center']),root_joint=matches[0][2],pin_to_bracket=matches[1][2],pin_to_inner_beam=next(j for si,h,j in bj if si==pin),root_to_inner_beam=next(j for si,h,j in bj if si==crossshaft),two_point_connection=True,cross_phase_cardinal_alignment=True,pin_collar=dict(center_error_to_interface_mm=max(shared,shared2),nominal_span_from_interface_mm=[-.8,.8],actual_radius_max_mm=collar_r.max(),host_mouth_radius_mm=3.2,host_mouth_depth_each_side_mm=.8,nominal_radial_margin_mm=3.2-collar_r.max(),max_collar_excess_beyond_nominal_16gon_recess_mm=collar_polygon_excess,recess_fits_with_mesh_rounding_tolerance_mm=.001))
 results.append(row)
 # Local mesh checks for brackets against every retained part. Permit only
 # the designed pin ridges (maximum .101 mm radial interference) and collar
 # primitive rounding (.001 mm); cross engagement is not blanket ignored.
 A=c.world(p)
 for j,q in enumerate(pp):
  if i==j:continue
  B=c.world(q)
  if not np.all(A.min((0,1))<=B.max((0,1))+1e-7) or not np.all(B.min((0,1))<=A.max((0,1))+1e-7):continue
  def allowed(pt):
   if j!=pin:return False
   l=(pt-origin)@pp[pin].rot;t=abs(l[0]);r=np.linalg.norm(l[1:])
   # radius 6 nominal core with factory friction ribs up to approx 6.25 LDU
   # and detent tips radius 6.5 inside 8 LDU end recesses.
   return (t<=.8001 and r<=3.201) or (.8-1e-4<=t<=7.2+1e-4 and r<=2.502) or (7.2-1e-4<=t<=8.0001 and r<=2.601)
  hit,matings=strict_hit(A,B,allowed)
  classified=[]
  for w in matings:
   pl=(np.array(w['point'])-origin)@pp[pin].rot
   sources=[triangle_sources(p.name)[w['triangles'][0]],triangle_sources(q.name)[w['triangles'][1]]]
   classification=('collar_recess_primitive_rounding' if abs(pl[0])<=.8001 else 'native_friction_rib_in_round_bore' if sources[1]['section']=='friction_ribs' else 'nominal_shaft_core_mesh_contact')
   classified.append(dict(w,pin_local_mm=pl,radial_distance_mm=np.linalg.norm(pl[1:]),classification=classification,triangle_sources=sources))
  assert all(x['classification']!='nominal_shaft_core_mesh_contact'for x in classified)
  surface_rows.append(dict(bracket_index=i,other=desc(pp,j),unexpected_strict_surface_crossing=hit,expected_pin_fit_crossings=classified))
  assert hit is None, (i,j,hit)

# Root-axle stack includes all aligned true bores. It is a closed nominal64mm
# stack, with no unmodelled claim of assembly play or measured retention force.
root_rows=[]
for si in roots:
 s=pp[si];ax=s.rot[:,0];scenter=s.pos*.4;stack=[]
 for hi,hp in enumerate(pp):
  if hi==si or not hp.head:continue
  for h in worldports(hp):
   if all(v<1e-6 for v in common_axis_distance(s,h)):
    j=joint(s,h)
    if j['engagement_mm']>1e-6:
     span=j['port_span_mm']-scenter@ax
     stack.append(dict(host=desc(pp,hi),span_relative_root_mm=span,**j))
 stack.sort(key=lambda z:z['span_relative_root_mm'][0])
 gaps=[stack[k+1]['span_relative_root_mm'][0]-stack[k]['span_relative_root_mm'][1] for k in range(len(stack)-1)]
 assert len(stack)==9 and all(j['full_depth']for j in stack) and np.max(np.abs(gaps))<1e-6
 assert [x['host']['name']for x in stack]==['32123a.dat','60483.dat',pp[stack[2]['host']['index']].name,'3713.dat','32524.dat','3713.dat',pp[stack[6]['host']['index']].name,'60483.dat','32123a.dat']
 root_rows.append(dict(root=desc(pp,si),stack=stack,adjacent_nominal_gaps_mm=gaps,axial_span_mm=64.,axle_end_reserve_mm=0.,outside_half_bush_engagement_each_mm=4.,jaw_bore_kind=stack[4]['kind'],jaw_free_turn_requires_not_compressing_bush_faces=True,retention='Two external half bushes and two internal full bushes retained; friction-on-axle axial retention, not a positive latch or a verified pull-out capacity.'))

# Rigid common transforms should preserve everything, but validate actual
# module generation and all four arm transforms over representative poses.
poses=[]
for open_s in [0.,m.OPEN_S/2,m.OPEN_S]:
 for angle in [0.,17.25,90.,180.,270.]:
  parts=c.module(open_s,angle,on_base=True)
  for arm in m.ARMS:
   work=[q.moved(m.ARM_ROT[arm])for q in parts]
   errs=[]
   for b in [p for p in work if p.name=='60483.dat']:
    for h in worldports(b):
     ids=[p for p in work if (p.name=='3707.dat'and p.head)if h['kind']=='cross_bore'] if h['kind']=='cross_bore' else [p for p in work if p.note=='限位支架固定销']
     vals=[(s,joint(s,h))for s in ids if all(v<1e-6 for v in common_axis_distance(s,h)) and joint(s,h)['engagement_mm']>1e-6]
     assert len(vals)==1 and vals[0][1]['full_depth']
     errs.append(vals[0][1]['offset_mm'])
   poses.append(dict(open_stroke_ldu=open_s,head_angle_deg=angle,arm=arm,max_axis_offset_mm=max(errs),connections=8))

after=immutable_hashes();assert before==after
summary=dict(status='PASS nominal local attachment geometry; physical/tolerance qualifications remain',native_ports=native,standalone_module_on_base_false=dict(baseline_parts=len(base),candidate_parts=len(pp),removed_parts=14,new_parts=4,net_change=-10,retained_parts_unchanged=len(retained)),installed_module_on_base_true=dict(baseline_parts=len(c.BASE_MODULE(on_base=True)),candidate_parts=len(c.module(on_base=True)),net_change=-10),brackets=results,root_stacks=root_rows,local_surface_checks=surface_rows,pose_checks=poses,source_hashes=before,immutable_sources_unchanged=True,method_limits=['No force, fatigue, plastic tolerance, friction or flexure simulation.','LDraw mesh is nominal and some mating faces/radii have zero designed clearance; small primitive-coordinate rounding may produce microscopic contact artifacts.','Axle and pin length checks use the actual mesh endpoints; pin ribs intentionally interfere with round-bore core and detents occupy end recesses.','Root stack has zero nominal end reserve and zero nominal axial play, inherited from baseline; do not push collars hard against the freely rotating jaw.','Removing both transverse stop axles eliminates those cross-ties and the abnormal-opening hard stop; this local joint audit does not replace whole-mechanism kinematic/load testing.'])
dump('engagement_audit.json',summary)
print(json.dumps(dict(status=summary['status'],brackets=len(results),two_point_connections=sum(r['two_point_connection']for r in results),root_engagement_mm=[r['root_joint']['engagement_mm']for r in results],pin_engagement_mm=[r['pin_to_bracket']['engagement_mm']for r in results],root_stacks=len(root_rows),surface_pairs=len(surface_rows),unexpected_surface_crossings=sum(r['unexpected_strict_surface_crossing']is not None for r in surface_rows),pose_count=len(poses),source_unchanged=True),indent=2))
