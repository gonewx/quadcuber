from candidate import *
import json,hashlib,collections
OUT=HERE/'models';OUT.mkdir(exist_ok=True)
rows=json.loads((HERE/'source/assembly132.json').read_text())
baselines=(HERE/'source/baseline-machine-899.mpd').read_text().split('\n0 FILE ',1)[0]
base=[]
for line in [l for l in baselines.splitlines()if l.startswith('1 ')][132:191]:
 s=line.split();v=np.array(s[2:14],float);base.append(m.Part(s[14],int(s[1]),v[:3],v[3:].reshape(3,3),0))
assert len(base)==59
assets='\n'.join('0 FILE '+name+'\n'+'\n'.join(lines)for name,lines in files.items()if name!='machine_working-899.ldr')+'\n'
states={
 'loading-all50':(50,50,True,True,0,True),
 'FB0-open':(50,0,True,True,0,True),
 'FB0-held':(50,0,True,False,0,True),
 'support-unlocked':(50,0,True,False,0,False),
 'support-down40':(50,0,True,False,40,False),
 'LR90-open':(90,0,True,False,40,False),
 'both-held':(90,0,False,False,40,False)}
manifest={}
def export(name,parts):
 text='0 FILE '+name+'.ldr\n0 ISOLATED REVIEW CANDIDATE - NO PHYSICAL OR POWERED ACCEPTANCE\n'+'\n'.join(p.ldraw()for p in parts)+'\n'+assets
 path=OUT/(name+'.mpd');path.write_text(text);return {'file':str(path.relative_to(HERE)),'parts':len(parts),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
for key,(lr,fb,lo,fo,drop,locks) in states.items():
 state={k:(m.OPEN_S if(lo if k in'LR'else fo)else 0,lr if k in'LR'else fb)for k in m.ARMS}
 head=state_parts(state);old=state_parts(state,False);retained=[p for p in old if not(p.note in ['开限位挡轴','开限位挡轴轴套']or(p.name=='32056.dat'and p.note=='限位支架'))]
 assert collections.Counter(p.ldraw()for p in retained)==collections.Counter(p.ldraw()for p in head if p.name!='60483.dat')
 core=[m.Part(r['name'],r['color'],np.array(r['position_ldu'])+np.array([0,drop/.4 if r['role']=='moving'else 0,0]),r['rotation'],0,r['note'])for r in rows if locks or r['role']!='key']
 allp=core+base+head;manifest[key]=export(key,allp);manifest[key].update(drop_mm=drop,locks=locks,heads={k:[float(v[0]),v[1]]for k,v in state.items()},unchanged_retained_parts=652,removed=dict(collections.Counter(p.name for p in old)-collections.Counter(p.name for p in head)),added=dict(collections.Counter(p.name for p in head)-collections.Counter(p.name for p in old)))
 assert len(head)==668 and len(allp)==(859 if locks else 857)
manifest['head-open25']=export('head-open25',module(m.OPEN_S))
manifest['head-closed']=export('head-closed',module(0))
(HERE/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2))
checks={'baseline_source_matches_github_current':(HERE/'source/baseline_model.py').read_bytes()==(HERE/'source/github-current-model.py').read_bytes(),'source_url':'https://github.com/gonewx/quadcuber/blob/main/tools/lego/v4/model.py','source_sha256':hashlib.sha256((HERE/'source/baseline_model.py').read_bytes()).hexdigest(),'assembly132_sha256':hashlib.sha256((HERE/'source/assembly132.json').read_bytes()).hexdigest(),'baseline_mpd_sha256':hashlib.sha256((HERE/'source/baseline-machine-899.mpd').read_bytes()).hexdigest(),'normal_open_deg':math.degrees(m.OPEN_BETA),'normal_open_stroke_mm':m.OPEN_S*.4,'natural_stroke_mm':natural_stroke()*.4,'natural_jaw_deg':math.degrees(m.jaw_beta(natural_stroke())),'preserved_retained_per_head':163,'removed_per_head':{'32056.dat':8,'3707.dat':2,'32123a.dat':4},'added_per_head':{'60483.dat':4},'preserved_support132':True,'preserved_base59':True,'original_8_wall_pin_HOLD':'unchanged','all_7_state_retained_parts_exact':True,'root_axles_bushes_fixing_pins':'all retained exactly','notes':'Candidate adapter changes no source constraints/firmware. Natural endpoint is analysis only; powered overtravel not authorized.'}
(HERE/'baseline-diff.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
