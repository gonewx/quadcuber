from candidate import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
fig=plt.figure(figsize=(15,8),facecolor='#f5f7fa')
for k,(label,pp)in enumerate([('BASELINE: paired thin L brackets + stop axles',BASE_MODULE(m.OPEN_S,0,False,True)),('CANDIDATE: four 60483 brackets; root restraints retained',module(m.OPEN_S))]):
 ax=fig.add_subplot(1,2,k+1,projection='3d');ax.set_facecolor('#f5f7fa')
 show=[p for p in pp if p.head and (p.pos[0]>-230)]
 for p in show:
  w=world(p)
  color=('#10a9a1'if p.name=='60483.dat'else '#a0a9b8'if p.note=='限位支架'else '#bc56c9'if p.note in ['开限位挡轴','开限位挡轴轴套']else {4:'#d83a41',14:'#edc63f',0:'#404754',72:'#56606d',71:'#a4afbe',1:'#347cc4'}.get(p.color,'#bec8d3'))
  pc=Poly3DCollection(w,facecolors=color,edgecolors='none',linewidth=0,alpha=1);ax.add_collection3d(pc)
 ax.set(xlim=(-101,-15),ylim=(-60,60),zlim=(-39,39),xlabel='X mm',ylabel='Y mm',zlabel='Z mm');ax.set_box_aspect((86,120,78));ax.view_init(elev=24,azim=-52);ax.set_title(label,fontsize=11,pad=15)
fig.suptitle('60483 arm-root candidate | actual embedded LDraw triangle geometry',fontsize=17,y=.96)
fig.text(.5,.035,'Jaw opening 25 degrees. Teal = new 60483; magenta = removed stop parts. Review candidate only: no strength or powered-motion acceptance.',ha='center',fontsize=10)
plt.tight_layout(rect=[0,.06,1,.94]);fig.savefig(HERE/'60483-actual-mesh-comparison.png',dpi=180);plt.close(fig)
