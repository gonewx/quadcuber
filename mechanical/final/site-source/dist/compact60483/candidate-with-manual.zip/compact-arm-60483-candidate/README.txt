60483夹指根部短支架候选（独立、可回退）

这是设计审查包，不是装配/带电试机放行。

候选改动：每个机械头原8片32056（三乘三L薄梁）改为4件60483（1×2厚梁，一十字孔一圆孔）。同时移除每头2根3707横向开限位挡轴及其4只32123a半轴套。保留夹指根轴、根轴内整轴套、外半轴套及4枚2780支架固定销。四头共增加16件60483，移除32片32056、8根挡轴、16只挡轴半套，净减40件。

整机上位899→859件；下位拔去2枚升降工作锁销后897→857件。支承132件和保留底盘59件完全不变。未叠加11478、未换18654、未改原8墙脚销HOLD、未改固件、未改原GitHub模型；本版只同步私人候选站点。

models/内为完整内嵌零件几何的LDraw MPD：
- loading-all50：四头50°、夹指25°张开、托座上位
- FB0-open：FB回0°、LR50°，夹指仍张开
- FB0-held：FB0°夹持、LR50°张开
- support-unlocked：抽掉两工作锁销
- support-down40：托座下降40mm
- LR90-open：LR转至90°、夹指张开
- both-held：FB0°/LR90°均夹持、托座下位
- head-closed / head-open25：单头候选细看

角度区分：50°、0°、90°是整个机械头的回转姿态；25°是夹指开角。候选正常开合约3.8417°→25°。名义伺服连杆自然伸直端点为夹指30.8722503°、推杆15.4194838mm。这是几何极限计算，不能当作可靠的实体限位、归零方法或持续顶住的伺服工作端点。候选删去了原约30°异常保护挡轴；因此实体装配和低能量验证前仍须保持原25°软件正常范围。

复现：Python3 + numpy；图像另需matplotlib，运动交叉筛查需g++（支持C++17）。源码包不依赖外部零件下载。
  python build_candidate.py
  python test_candidate.py
  python render_candidate.py
独立接合/运动检查见structure/及motion/中的脚本与结果。几何库内嵌于source/baseline-machine-899.mpd和parts/。baseline_model.py是冻结原件，candidate.py为替换适配器；二者分开，不覆盖原件。原源文件包含旧件的搭建说明，不是此候选的新版搭建手册。

来源：
https://github.com/gonewx/quadcuber/blob/main/tools/lego/v4/model.py
https://library.ldraw.org/library/official/parts/60483.dat
https://library.ldraw.org/library/official/parts/s/60483s01.dat
读取核对日期2026-10-07；GitHub当前文件与本包冻结源逐字节相同。60483官方零件Philo、子零件jb70，LDraw标注CC BY4.0（https://creativecommons.org/licenses/by/4.0/）。原有嵌入零件保留各自作者及许可证说明。

不变的限制：原8墙脚销HOLD；未验证加载刚度/下垂、摩擦保持、实体半套防脱、销尖掠孔卡滞、两工作锁销的完整插拔空间、人体/手指空间、任意四头混合转动或实际控制联锁。本包不提供舵机命令，也不把名义轮胎预压当成可靠抓持力。

新版补充说明（R1，2026-10-07）：manual/manual60483.pdf为24页／22步候选改装说明，包含逐侧拆换、防掉落保持、真实LDraw网格图、库存增减、四头重复及回退。manual/guide.json与manual60483.md是可编辑说明源；渲染脚本同目录。仅验证名义最终配合，拆装路径尚未做连续碰撞核验和实体试验，不是实体装配或带电试机放行。原有模型几何保持原哈希。
