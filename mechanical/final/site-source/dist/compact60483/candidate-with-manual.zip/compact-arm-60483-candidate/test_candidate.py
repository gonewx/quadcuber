import unittest,collections,json,hashlib
from candidate import *
class CandidateTests(unittest.TestCase):
 def test_current_source(self):
  self.assertEqual((HERE/'source/baseline_model.py').read_bytes(),(HERE/'source/github-current-model.py').read_bytes())
 def test_all_retained_parts_all_poses(self):
  for stroke in [0,m.OPEN_S/2,m.OPEN_S]:
   for roll in [0,50,90,180,270,360]:
    old=BASE_MODULE(stroke,roll,False,True);new=module(stroke,roll)
    kept=[p for p in old if p.note not in ['开限位挡轴','开限位挡轴轴套','限位支架']]
    self.assertEqual(collections.Counter(p.ldraw()for p in kept),collections.Counter(p.ldraw()for p in new if p.name!='60483.dat'))
    self.assertEqual(len(new),167)
    self.assertEqual(sum(p.name=='60483.dat'for p in new),4)
    self.assertTrue(all(abs(np.linalg.det(p.rot)-1)<1e-8 for p in new))
 def test_full_exports(self):
  man=json.loads((HERE/'candidate-manifest.json').read_text())
  for k,r in man.items():
   p=HERE/r['file'];self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),r['sha256'])
   top=p.read_text().split('\n0 FILE ',1)[0];lines=[l for l in top.splitlines()if l.startswith('1 ')];self.assertEqual(len(lines),r['parts'])
   for line in lines:self.assertGreater(len(mesh(line.split()[-1])),0)
 def test_part_geometry(self):
  self.assertEqual(mesh('60483.dat').shape,(536,3,3))
  np.testing.assert_allclose([mesh('60483.dat').min((0,1)),mesh('60483.dat').max((0,1))],[[-9,-10,-9],[9,10,29]])
 def test_actual_frozen_baseline(self):
  source=(HERE/'source/baseline-machine-899.mpd').read_text().split('\n0 FILE ',1)[0]
  old=[l for l in source.splitlines()if l.startswith('1 ')][191:]
  calc=state_parts({a:(m.OPEN_S,50)for a in m.ARMS},False)
  self.assertEqual(collections.Counter(old),collections.Counter(p.ldraw()for p in calc))
if __name__=='__main__':unittest.main(verbosity=2)
